# RE0 OpenAPI 第三方开发者接入指南

本文档面向第三方开发者，说明如何接入 RE0 OpenAPI。示例域名使用 `https://re0.me`，私有部署或测试环境请替换为实际域名。

## 0. 官方示例下载

- Go SDK：`/downloads/openapi-sdks/re0-openapi-sdk-go.zip`
- Python SDK：`/downloads/openapi-sdks/re0-openapi-sdk-python.zip`
- Node SDK：`/downloads/openapi-sdks/re0-openapi-sdk-node.zip`
- 全量压缩包：`/downloads/openapi-sdks/re0-openapi-sdks-all.zip`


推荐的客户端处理顺序：

1. 调业务接口
2. 命中 `OPENAPI_REFRESH_REQUIRED` 时刷新一次
3. 用新的 access token 重试一次
4. 若刷新接口返回 `OPENAPI_REAUTH_REQUIRED`，重新发起 OAuth 授权

## 1. 接入前准备

接入方需要先申请 OpenAPI 应用：

1. 在 RE0 创建 OpenAPI 应用。
2. 填写应用名称、用途、回调模式、回调地址和需要的接口 scope。
3. 提交审核。
4. 审核通过后保存：
   - `client_id`：公开应用 ID，用于授权页。
   - 应用 Secret：服务端密钥，用于 `X-API-Key`。

应用 Secret 只允许保存在服务端，不能放进浏览器、移动端明文包、公开仓库或前端环境变量。

## 2. 接口地址与认证头

| 类型 | 地址 |
|---|---|
| 授权页 | `https://re0.me/openapi/authorize` |
| OAuth 接口 | `https://re0.me/api/public/openapi/oauth` |
| 业务接口 | `https://re0.me/api/open` |

业务接口必须携带应用 Secret：

```http
X-API-Key: app-secret
```

代表用户执行操作时，还需要携带用户 Access Token：

```http
Authorization: Bearer user-access-token
```

站内登录态 JWT 不再适用于 `/api/open/*` 业务接口。

完整请求头示例：

```http
X-API-Key: app-secret
Authorization: Bearer user-access-token
Content-Type: application/json
```

## 3. 快速验证应用 Secret

审核通过后，可先调用健康检查接口验证应用 Secret：

```bash
curl -H "X-API-Key: app-secret" https://re0.me/api/open/ping
```

成功响应：

```json
{
  "success": true,
  "code": "200",
  "message": "success",
  "data": {
    "message": "pong",
    "api_key_id": 1,
    "name": "My OpenAPI App"
  }
}
```

如果返回 `MISSING_API_KEY`、`INVALID_API_KEY`、`DISABLED_API_KEY` 或 `EXPIRED_API_KEY`，请检查应用 Secret、审核状态和应用启用状态。

## 4. OAuth 用户授权

第三方应用需要代表用户查询、解锁、签到或管理分享时，应先引导用户授权。

### 授权页 URL

```text
https://re0.me/openapi/authorize?client_id=app_xxx&redirect_uri=https%3A%2F%2Fclient.example.com%2Fcallback&scope=query%20unlock&state=opaque-state
```

参数说明：

| 参数 | 必填 | 说明 |
|---|---|---|
| `client_id` | 是 | OpenAPI 应用公开 ID |
| `redirect_uri` | 是 | 授权完成后的回调地址，必须与应用配置匹配 |
| `scope` | 否 | 请求授权范围，多个 scope 用空格分隔 |
| `state` | 是 | 接入方生成的随机状态值，用于防 CSRF |
| `response_mode` | 否 | `redirect`、`postmessage` 或 `webhook`，必须与应用固定模式一致 |

`state` 必须不可预测，并在回调时校验一致。

### 回调模式

| 模式 | 授权结果 | 说明 |
|---|---|---|
| `redirect` | 浏览器跳转到 `redirect_uri?code=...&state=...` | 最常见的 Web 服务端接入方式 |
| `postmessage` | 弹窗向 opener 发送授权结果 | 适合弹窗授权体验 |
| `webhook` | HDHive 服务端 POST 授权结果到应用 Webhook | 适合服务端异步接收 |

授权码 `code` 只能使用一次，有效期较短。收到授权码后，应立即在服务端换取用户 Token。

## 5. 换取、刷新与撤销用户 Token

### 授权码换 Token

```bash
curl -X POST https://re0.me/api/public/openapi/oauth/token \
  -H "X-API-Key: app-secret" \
  -H "Content-Type: application/json" \
  -d '{
    "grant_type": "authorization_code",
    "code": "authorization-code",
    "redirect_uri": "https://client.example.com/callback"
  }'
```

`redirect_uri` 必须与发起授权时完全一致。

成功响应：

```json
{
  "success": true,
  "code": "200",
  "message": "success",
  "data": {
    "access_token": "user-access-token",
    "refresh_token": "refresh-token",
    "token_type": "Bearer",
    "expires_in": 7200,
    "refresh_expires_in": 2592000,
    "scope": "query unlock",
    "scopes": ["query", "unlock"]
  }
}
```

### 刷新 Token

```bash
curl -X POST https://re0.me/api/public/openapi/oauth/refresh \
  -H "X-API-Key: app-secret" \
  -H "Content-Type: application/json" \
  -d '{
    "refresh_token": "refresh-token"
  }'
```

业务接口返回 `OPENAPI_REFRESH_REQUIRED` 时，应调用刷新接口获取新的 Access Token。
如果刷新接口返回 `OPENAPI_REAUTH_REQUIRED`，说明 Refresh Token 已失效、被撤销，或授权用户/应用状态已变化，此时应重新发起 OAuth 授权。

### 撤销 Refresh Token

```bash
curl -X POST https://re0.me/api/public/openapi/oauth/revoke \
  -H "X-API-Key: app-secret" \
  -H "Content-Type: application/json" \
  -d '{"refresh_token":"refresh-token"}'
```

## 6. 调用业务接口

### 查询资源

```bash
curl -H "X-API-Key: app-secret" \
  -H "Authorization: Bearer user-access-token" \
  https://re0.me/api/open/resources/movie/550
```

### 解锁资源

`/api/open/resources/unlock` 兼容旧版单个 `slug`，也支持 `slugs` 批量解锁。

接入建议：

1. 单资源解锁时只传 `slug`。
2. 批量解锁时只传 `slugs`。
3. 如果同时传了 `slug` 和 `slugs`，服务端会合并去重后按批量模式处理。

```bash
curl -X POST https://re0.me/api/open/resources/unlock \
  -H "X-API-Key: app-secret" \
  -H "Authorization: Bearer user-access-token" \
  -H "Content-Type: application/json" \
  -d '{"slug":"a1b2c3d4e5f647898765432112345678"}'
```

成功响应：

```json
{
  "success": true,
  "code": "200",
  "message": "解锁成功",
  "data": {
    "url": "https://pan.example.com/s/abc123",
    "access_code": "x1y2",
    "full_url": "https://pan.example.com/s/abc123?pwd=x1y2",
    "already_owned": false
  }
}
```

批量解锁示例：

```bash
curl -X POST https://re0.me/api/open/resources/unlock \
  -H "X-API-Key: app-secret" \
  -H "Authorization: Bearer user-access-token" \
  -H "Content-Type: application/json" \
  -d '{"slugs":["a1b2c3d4e5f647898765432112345678","b2c3d4e5f64789876543211234567890"]}'
```

批量模式要点：

1. 普通用户单次最多 1 个资源。
2. 普通 VIP 单次最多 5 个资源。
3. 长期 VIP 单次最多 10 个资源。
4. 一次批量请求无论包含多少个资源，都只计 1 次 OpenAPI 用户级 QPS 请求。

批量响应要点：

1. HTTP 可能仍返回 `200`。
2. 单个资源的成功或失败体现在 `data.items[].success`。
3. 单个资源失败时，查看 `data.items[].error_code` 与 `data.items[].message`。
4. 常见 item 级错误码包括 `RESOURCE_NOT_FOUND`、`INSUFFICIENT_POINTS`、`UNLOCK_FAILED`。

当前官方 SDK 说明：

1. 现有 Go / Python / Node SDK 不是最新版，只保留基础调用封装，未覆盖当前全部 OpenAPI 能力。
2. 接口路径、字段、认证、错误码和限制请以 `/manager/api-docs` 及本下载包中的 Markdown 文档为准。
3. SDK 的 `unlock` 便捷方法仍以单个 `slug` 为输入；批量解锁请直接调用 `POST /api/open/resources/unlock` 并传 `{"slugs":[...]}`，或在本地复制版 SDK 上自行补一个 batch helper。

### 查询当前用户信息

```bash
curl -H "X-API-Key: app-secret" \
  -H "Authorization: Bearer user-access-token" \
  https://re0.me/api/open/me
```

### 每日签到

```bash
curl -X POST -H "X-API-Key: app-secret" \
  -H "Authorization: Bearer user-access-token" \
  -H "Content-Type: application/json" \
  -d '{}' \
  https://re0.me/api/open/checkin
```

成功时 `data.points` 为本次签到获得的积分（4–10，Premium 用户按站内倍率加成）；当天已签到则 `data.checked_in=false` 且 `data.points=0`。当前积分总额见 `GET /api/open/me` 的 `data.points`。

## 7. 接口能力清单

| scope | 方法 | 路径 | 能力 |
|---|---|---|---|
| `meta` | GET | `/api/open/ping` | 验证应用 Secret |
| `meta` | GET | `/api/open/quota` | 查询配额状态 |
| `meta` | GET | `/api/open/usage` | 查询历史用量 |
| `meta` | GET | `/api/open/usage/today` | 查询今日用量 |
| `query` | GET | `/api/open/resources/:type/:tmdb_id` | 查询资源列表 |
| `query` | GET | `/api/open/resources/file-list/:slug` | 按资源 slug 预览文件列表，非 Premium 也可调用；默认缓存 12 小时，`refresh=1` 强制刷新 |
| `query` | POST | `/api/open/check/resource` | 检查资源链接 |
| `query` | GET | `/api/open/shares/:slug` | 查询分享详情 |
| `unlock` | POST | `/api/open/resources/unlock` | 单个或批量解锁资源 |
| `points` | POST | `/api/open/points/debit` | 扣除积分（第三方内购） |
| `points` | POST | `/api/open/points/refund` | 按原交易全额退回积分 |
| `write` | GET | `/api/open/shares` | 查询我的分享 |
| `write` | POST | `/api/open/shares` | 创建分享 |
| `write` | PATCH | `/api/open/shares/:slug` | 更新分享 |
| `write` | DELETE | `/api/open/shares/:slug` | 删除分享 |
| `subscription` | GET | `/api/open/subscriptions` | 查询我的作者/资源/片单/追更订阅 |
| `subscription` | POST | `/api/open/subscriptions` | 创建作者、媒体资源、片单或已解锁追更包订阅 |
| `subscription` | GET | `/api/open/subscriptions/check` | 检查是否已订阅 |
| `subscription` | DELETE | `/api/open/subscriptions/:id` | 取消订阅 |
| `query` | GET | `/api/open/tv-follow/packs` | 按剧集查询追更包 |
| `write` | POST/PATCH/DELETE | `/api/open/tv-follow/packs...` | 发布和维护追更包 |
| `unlock` | POST | `/api/open/tv-follow/packs/:slug/unlock` | 解锁追更资源，可用 `subscribe_updates` 选择订阅 |
| `query` | GET | `/api/open/tv-follow/packs/:slug/items` | 获取已解锁追更资源，最新季集优先 |
| `write` | POST | `/api/open/tv-follow/packs/:slug/items` | 批量新增追更资源，最多 500 条 |
| `write` | PATCH/DELETE | `/api/open/tv-follow/items/:id` | 更新或删除追更资源 |
| `query` | GET | `/api/open/tv-follow/my` | 查询我的已解锁追更包 |
| `messages` | GET | `/api/open/messages` | 查询站内信列表 |
| `messages` | GET | `/api/open/messages/unread-count` | 查询站内信未读数 |
| `messages` | POST | `/api/open/messages/:id/read` | 标记单条站内信已读 |
| `messages` | POST | `/api/open/messages/read` | 批量标记站内信已读 |
| `messages` | POST | `/api/open/messages/read-all` | 标记全部或指定分类站内信已读 |
| `messages` | DELETE | `/api/open/messages/read` | 删除已读站内信 |
| `query` | GET | `/api/open/me` | 当前授权用户基础信息 |
| `write` | POST | `/api/open/checkin` | 每日签到；返回 `data.points` 本次获得积分 |
| `vip` | GET | `/api/open/vip/entitlements` | 当前 Premium 用户权益摘要 |
| `vip` | GET | `/api/open/vip/weekly-free-quota` | 长期 Premium 每周免费解锁状态 |

## 8. 限流、冷却和 IP 策略

HDHive OpenAPI 会按全局、应用、授权用户和解锁行为分层保护服务稳定性。具体阈值由平台配置，不在对外文档中固定公开。

当请求返回 `429`：

1. 读取 `Retry-After` Header。
2. 读取响应体中的 `retry_after_seconds`。
3. 按 `limit_scope` 判断退避对象。

```json
{
  "success": false,
  "code": "USER_RATE_LIMIT_EXCEEDED",
  "message": "User OpenAPI rate limit exceeded",
  "description": "用户 OpenAPI 请求频率过高，当前授权用户已进入冷却，请稍后重试",
  "limit_scope": "user",
  "limit_scope_label": "授权用户",
  "retry_after_seconds": 300
}
```

| `limit_scope` | 处理方式 |
|---|---|
| `global` | 平台全局流量保护，当前应用应整体降低请求速率 |
| `app` | 当前应用受限，所有使用该应用的请求都应退避 |
| `user` | 当前授权用户受限，不代表整个应用不可用 |

如应用配置了 IP 白名单或动态 IP 策略，请确保服务端出口 IP 稳定，并提前提供需要放行的 IP 或 CIDR。

## 9. 错误响应处理

统一错误格式：

```json
{
  "success": false,
  "code": "ERROR_CODE",
  "message": "Error message",
  "description": "详细说明"
}
```

常见错误：

| 错误码 | HTTP 状态码 | 处理建议 |
|---|---|---|
| `MISSING_API_KEY` | 401 | 检查是否发送 `X-API-Key` |
| `INVALID_API_KEY` | 401 | 检查应用 Secret、审核状态和是否使用了旧个人 Key |
| `INVALID_OPENAPI_USER_TOKEN` | 401 | 检查 access token 格式与签名，必要时重新授权 |
| `OPENAPI_REFRESH_REQUIRED` | 401 | 使用 Refresh Token 刷新 access token |
| `OPENAPI_REAUTH_REQUIRED` | 401 | 引导用户重新完成 OAuth 授权 |
| `OPENAPI_USER_REQUIRED` | 401 | 引导用户完成 OAuth 授权 |
| `SCOPE_NOT_ALLOWED` | 403 | 检查应用申请的 scope |
| `USER_SCOPE_NOT_ALLOWED` | 403 | 检查用户授权时请求的 scope |
| `VIP_REQUIRED` | 403 | 当前用户不满足 Premium 要求 |
| `STATE_REQUIRED` | 400 | 授权链接必须带 `state` |
| `RISK_BLOCKED` | 403 | 当前用户风险状态暂不允许授权 |
| `USER_TIER_NOT_ALLOWED` | 403 | 当前用户等级不允许授权该应用等级 |
| `GLOBAL_RATE_LIMIT_EXCEEDED` | 429 | 按 `Retry-After` 整体退避 |
| `APP_RATE_LIMIT_EXCEEDED` | 429 | 当前应用整体退避 |
| `USER_RATE_LIMIT_EXCEEDED` | 429 | 当前授权用户退避 |
| `OPENAPI_COOLDOWN` | 429 | 按返回的冷却时间等待 |
| `IP_NOT_ALLOWED` | 403 | 检查 `description` 中的出口 IP 和应用白名单 |
| `IP_COUNT_EXCEEDED` | 429 | 动态 IP 数过多，应用进入冷却 |
| `INSUFFICIENT_POINTS` | 402 | 用户积分不足，无法解锁或扣费 |
| `IDEMPOTENCY_CONFLICT` | 409 | 相同幂等键用于不同积分请求 |
| `TRANSACTION_NOT_FOUND` | 404 | 原扣费交易不存在或不属于当前应用/用户 |
| `TRANSACTION_NOT_REFUNDABLE` | 409 | 交易已退款、非扣费单或退款金额不符 |
| `INVALID_AMOUNT` | 400 | 积分金额或幂等参数无效 |

## 10. 安全要求

1. 应用 Secret 和 Refresh Token 必须保存在服务端。
2. 不要在浏览器、移动端明文包或日志中输出应用 Secret。
3. 授权 `state` 必须随机、不可预测，并在回调时校验一致。
4. `redirect_uri` 支持 HTTP/HTTPS 完整地址；生产环境仍建议优先使用 HTTPS。
5. 交换授权码必须在服务端完成。
6. Access Token 到期后使用 Refresh Token 刷新；刷新失败时重新引导用户授权。
7. Webhook 模式必须校验 HDHive 签名，并做好幂等处理。
8. 对 429 做退避，不要在冷却期内持续重试。

## 11. 上线前检查清单

- [ ] 应用已通过 HDHive 审核。
- [ ] 服务端已安全保存应用 Secret。
- [ ] 回调地址与应用配置一致；生产环境优先使用 HTTPS。
- [ ] 授权链接始终携带不可预测的 `state`。
- [ ] 回调处理会校验 `state`。
- [ ] 授权码只在服务端换 Token。
- [ ] Refresh Token 加密或安全存储。
- [ ] 业务接口同时发送 `X-API-Key` 和用户 Access Token。
- [ ] 已处理 `401`、`403`、`429` 和 `5xx`。
- [ ] 已按 `Retry-After`、`limit_scope`、`retry_after_seconds` 实现退避。
- [ ] 不在客户端写死平台 QPS 或额度阈值。
