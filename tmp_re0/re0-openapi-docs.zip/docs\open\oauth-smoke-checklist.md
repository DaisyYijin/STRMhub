# OAuth 回调联调清单

这份清单对应 `plan.md` 阶段 4 的“手工脚本走完三种回调模式 happy path + 失败路径”。

适用前提：

- 应用已通过审核，`client_id` / 应用 Secret 可用
- 授权用户可以正常登录 RE0
- 如应用配置了固定回调白名单，`redirect_uri` 已加入白名单；未配置白名单时可使用动态回调地址
- `callback_mode=webhook` 时，`webhook_url` 必须是公网 HTTPS 地址，不能指向私网

## 0. 可选：使用本地 smoke CLI 减少手工复制

仓库内新增了 `scripts/openapi-oauth-smoke/`。它不会替代浏览器里的“登录 / 确认授权”动作，但可以把几段重复命令收起来：

```powershell
# 生成授权链接
go run ./scripts/openapi-oauth-smoke authorize-url `
  -base-url $env:HDHIVE_BASE_URL `
  -client-id $env:CLIENT_ID `
  -redirect-uri $env:REDIRECT_URI `
  -scope $env:SCOPE `
  -state $env:STATE `
  -response-mode redirect

# 校验 webhook 签名
go run ./scripts/openapi-oauth-smoke verify-webhook `
  -webhook-secret 'raw-webhook-secret' `
  -signature 't=1716055200,v1=abcdef...' `
  -code 'authorization-code-from-webhook' `
  -state $env:STATE `
  -client-id $env:CLIENT_ID

# code -> token，并先探测不依赖 Premium 的 /api/open/quota
go run ./scripts/openapi-oauth-smoke exchange `
  -base-url $env:HDHIVE_BASE_URL `
  -app-secret $env:APP_SECRET `
  -code 'authorization-code-from-callback' `
  -redirect-uri $env:REDIRECT_URI `
  -probe-endpoint quota
```

## 0. 准备环境变量

以下示例用 PowerShell。每轮联调都重新生成 `STATE`，避免复用。

```powershell
$env:HDHIVE_BASE_URL = 'https://hdhive.example.com'
$env:CLIENT_ID = 'app_xxx'
$env:APP_SECRET = 'oa_xxx'
$env:REDIRECT_URI = 'https://client.example.com/openapi/callback'
$env:SCOPE = 'meta'
$env:STATE = 'smoke-' + [guid]::NewGuid().ToString('N')
```

## 1. 生成授权链接

```powershell
$authorizeUrl = `
  "$env:HDHIVE_BASE_URL/openapi/authorize?client_id=$([uri]::EscapeDataString($env:CLIENT_ID))" + `
  "&redirect_uri=$([uri]::EscapeDataString($env:REDIRECT_URI))" + `
  "&scope=$([uri]::EscapeDataString($env:SCOPE))" + `
  "&state=$([uri]::EscapeDataString($env:STATE))"

$authorizeUrl
```

## 2. 用授权码换取用户 Token

把浏览器或 webhook 拿到的 `code` 写入 `$code` 后执行：

```powershell
$code = 'authorization-code-from-callback'

$tokenBody = @{
  grant_type   = 'authorization_code'
  code         = $code
  redirect_uri = $env:REDIRECT_URI
} | ConvertTo-Json

$token = Invoke-RestMethod `
  -Method Post `
  -Uri "$env:HDHIVE_BASE_URL/api/public/openapi/oauth/token" `
  -Headers @{ 'X-API-Key' = $env:APP_SECRET } `
  -ContentType 'application/json' `
  -Body $tokenBody

$token
```

## 3. 验证基础探针 `/api/open/quota`

```powershell
$accessToken = $token.data.access_token

Invoke-RestMethod `
  -Method Get `
  -Uri "$env:HDHIVE_BASE_URL/api/open/quota" `
  -Headers @{
    'X-API-Key' = $env:APP_SECRET
    'Authorization' = "Bearer $accessToken"
  }
```

成功标准：返回 `daily_reset` 等正常数据，证明“授权码 -> token -> OpenAPI bearer 调用”主链路已通。

## 3A. 可选：验证 `/api/open/me`

`/api/open/me` 现在属于基础查询接口。只要这次 smoke 已经拿到了有效的 OpenAPI Access Token，就应该继续执行这一项。

```powershell
Invoke-RestMethod `
  -Method Get `
  -Uri "$env:HDHIVE_BASE_URL/api/open/me" `
  -Headers @{
    'X-API-Key' = $env:APP_SECRET
    'Authorization' = "Bearer $accessToken"
  }
```

成功标准：返回当前授权用户基础信息，而不是应用绑定用户或匿名调用结果。

## 3B. 可选：验证 `/api/open/resources/unlock`

如果这次 smoke 的应用 scope 和用户授权 scope 已包含 `unlock`，建议再补一轮解锁联调。先准备 1-2 个真实资源 slug；批量模式支持带横杠或不带横杠 UUID。

单资源解锁：

```powershell
$singleUnlockBody = @{
  slug = 'a1b2c3d4e5f647898765432112345678'
} | ConvertTo-Json

Invoke-RestMethod `
  -Method Post `
  -Uri "$env:HDHIVE_BASE_URL/api/open/resources/unlock" `
  -Headers @{
    'X-API-Key' = $env:APP_SECRET
    'Authorization' = "Bearer $accessToken"
  } `
  -ContentType 'application/json' `
  -Body $singleUnlockBody
```

批量解锁：

```powershell
$batchUnlockBody = @{
  slugs = @(
    'a1b2c3d4e5f647898765432112345678',
    'b2c3d4e5f64789876543211234567890'
  )
} | ConvertTo-Json

Invoke-RestMethod `
  -Method Post `
  -Uri "$env:HDHIVE_BASE_URL/api/open/resources/unlock" `
  -Headers @{
    'X-API-Key' = $env:APP_SECRET
    'Authorization' = "Bearer $accessToken"
  } `
  -ContentType 'application/json' `
  -Body $batchUnlockBody
```

成功标准：

- 单资源模式返回 `url`、`access_code`、`full_url`、`already_owned` 等字段。
- 批量模式返回 `data.items`、`total`、`success_count`、`failed_count`。
- 如果需要验证 item 级失败，可在 `slugs` 中混入一个不存在的 UUID，预期 HTTP 仍为 `200`，但单条结果会返回 `success=false` 与 `error_code`。
- 一次批量请求无论包含多少个资源，都只应计为 1 次 OpenAPI 用户级 QPS 请求。

## 4. `redirect` 模式

### Happy Path

1. 用应用自身的 `redirect` 模式生成授权链接并在浏览器中打开。
2. 登录后点击“确认授权”。
3. 浏览器应跳回：

```text
https://client.example.com/openapi/callback?code=...&state=...
```

4. 复制 `code`，执行“2. 用授权码换取用户 Token”。
5. 再执行“3. 验证基础探针 `/api/open/quota`”。
6. 再补执行“3A. 可选：验证 `/api/open/me`”。
7. 如 scope 允许，再补执行“3B. 可选：验证 `/api/open/resources/unlock`”。

### Failure Path

1. 去掉 `state` 参数重新访问授权链接。
2. 预期授权页直接阻止继续授权，并提示重新从第三方应用发起。
3. 若应用配置了固定回调白名单，可以把 `redirect_uri` 改成白名单外地址，预期 `/api/public/openapi/oauth/authorize` 返回 4xx。
4. 若应用未配置固定白名单，可以把 `redirect_uri` 改成 `http://` 或 `https://` 的完整地址，预期均可进入授权流程；`redirect_uri` 仍不能包含 fragment。

## 5. `postmessage` 模式

### Happy Path

1. 准备一个父页面，用 `window.open(...)` 打开授权链接，并监听消息：

```javascript
window.addEventListener('message', (event) => {
  console.log('origin=', event.origin);
  console.log('payload=', event.data);
});
window.open(authorizeUrl, 'hdhive-oauth', 'width=520,height=760');
```

2. 应用固定 `callback_mode=postmessage`，并带上相同的 `redirect_uri` / `state`。
3. 用户在弹窗中确认授权后，父窗口应收到：

```json
{
  "source": "hdhive-openapi",
  "client_id": "app_xxx",
  "type": "authorization_response",
  "code": "...",
  "state": "..."
}
```

4. 用收到的 `code` 继续执行换 Token 与 `/api/open/quota` 校验，再补跑 `/api/open/me`；如 scope 允许，再补跑 `/api/open/resources/unlock` 单资源或批量解锁。

### Failure Path

1. 直接在当前标签页打开相同授权链接，不通过 `window.open(...)`。
2. 预期没有 `window.opener` 时自动降级成浏览器 redirect，而不是卡死在中间页。
3. 跳回 URL 仍应带 `code` 与 `state`。

## 6. `webhook` 模式

### Happy Path

1. 应用固定 `callback_mode=webhook`，并确认 `webhook_url` 指向自己的公网服务。
2. 浏览器中完成授权后，页面应跳回：

```text
https://client.example.com/openapi/callback?ok=1&state=...
```

3. 应用服务端应收到 webhook：

```json
{
  "client_id": "app_xxx",
  "code": "...",
  "state": "...",
  "expires_in": 600,
  "redirect_uri": "https://client.example.com/openapi/callback"
}
```

4. 校验 `X-HDHive-Signature`。下面的 PowerShell 片段可验证签名：

```powershell
$timestamp = '1716055200'
$signature = 'hex-from-header-v1'
$webhookSecret = 'raw-webhook-secret'
$code = 'authorization-code-from-webhook'

$secretHash = [System.BitConverter]::ToString(
  [System.Security.Cryptography.SHA256]::Create().ComputeHash(
    [System.Text.Encoding]::UTF8.GetBytes($webhookSecret)
  )
).Replace('-', '').ToLowerInvariant()

$payload = "$timestamp.$code.$env:STATE.$env:CLIENT_ID"
$hmac = [System.Security.Cryptography.HMACSHA256]::new(
  [System.Text.Encoding]::UTF8.GetBytes($secretHash)
)
$computed = [System.BitConverter]::ToString(
  $hmac.ComputeHash([System.Text.Encoding]::UTF8.GetBytes($payload))
).Replace('-', '').ToLowerInvariant()

"expected=$computed"
"actual=$signature"
```

5. 用 webhook body 中的 `code` 执行换 Token 与 `/api/open/quota` 校验，再补跑 `/api/open/me`；如 scope 允许，再补跑 `/api/open/resources/unlock` 单资源或批量解锁。

### Failure Path

1. 把 `webhook_url` 临时指向一个稳定返回 `500` 的公网测试地址。
2. 完成一次授权，记录第一次收到的 `code`。
3. 等待队列重试耗尽后，再用该 `code` 调 `/api/public/openapi/oauth/token`。
4. 预期换 Token 失败，且授权码已失效；服务端应能看到 `webhook_delivery_failed` 或 `webhook_enqueue_failed` 相关记录。

## 7. 额外风控回归

在三种模式之外，还需要单独验证两条拒绝链路：

1. `risk_level=high` 或命中 cooldown 的用户访问授权页时，返回 `RISK_BLOCKED`
2. 用户等级不满足应用 tier 时，授权页或 `/oauth/approve` 返回 `USER_TIER_NOT_ALLOWED`

## 8. 建议记录

每次 smoke run 至少记录以下证据，方便回写验收：

- 授权链接参数
- 最终 redirect URL 或 `postMessage` payload
- webhook 请求头与 body
- `/oauth/token` 成功或失败响应
- `/api/open/quota` 响应截图或日志
- `/api/open/me` 响应截图或日志
- `/api/open/resources/unlock` 的单资源或批量响应
- 失败路径下的服务端日志关键字
