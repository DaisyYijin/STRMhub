# RE0 OpenAPI

RE0 OpenAPI 面向第三方应用、自动化工具和可信服务端集成，提供资源查询、流媒体榜单、追剧日历、资源解锁、积分内购扣费/退款、分享管理、作者/资源/追更订阅、站内信、用户信息、签到、VIP 状态和用量查询能力。

本文档以当前后端 OpenAPI 路由、中间件和 `openapi_access_config` 配置为准。OpenAPI 属于对外契约，任何路由、认证、scope、限流、响应字段或错误码变更，都应同步更新本目录文档。

## 当前接入模型

新的第三方接入统一使用 **OpenAPI 应用**：

1. 开发者在 RE0 创建 OpenAPI 应用并提交审核。
2. 应用审核通过后获得公开 `client_id` 和应用 Secret。
3. 调用 `/api/open/*` 时，应用 Secret 放在 `X-API-Key` 请求头中。
4. 需要代表具体用户执行操作时，第三方应用应通过 OAuth 授权获得 OpenAPI 用户 Access Token，并在业务请求中附加 `Authorization: Bearer <access_token>`。

旧的个人 API Key 不再作为新的 OpenAPI 接入方式。迁移灰度期默认通过 `allow_legacy_personal_keys` 兼容历史个人 Key；迁移完成后应关闭该开关，并切换到 OpenAPI 应用和 OAuth 用户授权。

## Base URL

生产环境示例：

| 用途 | Base URL |
|---|---|
| 用户授权页 | `https://re0.me/openapi/authorize` |
| OAuth 授权接口 | `https://re0.me/api/public/openapi/oauth` |
| OpenAPI 业务接口 | `https://re0.me/api/open` |

本地或私有部署环境根据实际域名替换 `https://re0.me`。

## 能力范围

OpenAPI 按接口组进行 scope 管理：

| scope | 能力 | 典型接口 |
|---|---|---|
| `meta` | 健康检查、配额、用量 | `/ping`、`/quota`、`/usage` |
| `query` | 查询资源、分享、流媒体榜单、追剧日历和追更信息，解析资源链接，预览资源文件列表 | `/resources/:type/:tmdb_id`、`/resources/file-list/:slug`、`/streaming-top`、`/calendar`、`/tv-follow/packs` |
| `query` | 当前授权用户基础信息 | `/me` |
| `unlock` | 代表用户解锁普通资源或追更包 | `/resources/unlock`、`/tv-follow/packs/:slug/unlock` |
| `points` | 代表用户扣除/退回积分（第三方内购） | `/points/debit`、`/points/refund` |
| `write` | 代表用户管理分享、追更包和签到 | `/shares`、`/tv-follow/packs`、`/checkin` |
| `vip` | Premium 用户能力 | `/vip/entitlements`、`/vip/weekly-free-quota` |
| `subscription` | 代表用户订阅作者、媒体资源、片单或已解锁追更包的更新 | `/subscriptions`、`/subscriptions/check` |
| `messages` | 代表用户读取、标记和清理站内信 | `/messages`、`/messages/unread-count`、`/messages/read` |
| `points_ledger` | A 级合作方服务端读取已授权用户的完整积分流水 | `/api/internal/openapi/points-ledger/users/:user_id` |

应用本身必须拥有接口组 scope。若请求携带 OpenAPI 用户 Access Token，用户授权 scope 也必须覆盖目标接口组。

`points_ledger` 是管理员为 A 级合作方配置的 **service-only scope**：它不会出现在 OAuth 授权页、授权码、用户 grant、Access Token 或 Refresh Token 中，显式把它放进 OAuth `scope` 参数会返回 `400`。该能力还要求独立 GM 账本密钥、可撤销合作方服务凭证，以及目标用户对该应用仍然有效且包含既有 `points` scope 的 OAuth grant；不能使用应用 Secret、旧内部 Key 或 Next SSR Key 替代。

`/resources/unlock` 兼容旧版单个 `slug` 请求，也支持 `slugs` 批量解锁。批量模式的请求体、返回结构和分用户等级上限，见 [接口列表](endpoints.md)。

`points` 用于第三方游戏/应用内购：用户一次授权后，服务端可直接扣积分；定价由第三方自行决定。退款须指向原扣费 `transaction_id`，首版仅支持全额冲正。

订阅接口支持作者（`publisher`）、媒体资源（`media_resource`）、片单（`playlist`）和追更包（`tv_follow`）。创建 `tv_follow` 订阅前，当前用户必须已解锁对应追更包；解锁请求只有显式传入 `subscribe_updates: true` 才会同时创建订阅，取消订阅只停止通知，不撤销解锁权限。

追更包 CRUD、最多 500 条资源批量新增、解锁和“我的追更”查询均已开放，路径统一位于 `/api/open/tv-follow/*`；追更资源列表默认按最新季集倒序返回。完整契约见 [接口列表](endpoints.md#追更包接口)。

流媒体榜单和追剧日历均为 Premium 用户可用的 `query` scope 只读接口。榜单按平台、地区和媒体类型查询并返回 TMDB 标准数据；未匹配条目不会提供外部来源跳转。日历固定使用 `Asia/Shanghai` 时区。内部服务配置和缓存细节不属于公开契约。完整契约见 [接口列表](endpoints.md#流媒体榜单与追剧日历)。

## 推荐接入流程

1. 创建并提交 OpenAPI 应用，配置应用名称、用途、回调模式、回调地址和需要的 scope。
2. 审核通过后保存 `client_id` 和应用 Secret。应用 Secret 只允许保存在服务端。
3. 使用 `X-API-Key: <app-secret>` 调用 `GET /api/open/ping` 验证应用 Secret。
4. 将用户引导到授权页 `/openapi/authorize`，传入 `client_id`、`redirect_uri`、`scope` 和 `state`。
5. 用户确认授权后，按应用固定的 `callback_mode` 收到授权码。
6. 第三方服务端使用应用 Secret 调用 `POST /api/public/openapi/oauth/token` 换取用户 Token。
7. Access Token 过期时，第三方服务端调用 `POST /api/public/openapi/oauth/refresh` 刷新。
8. 调用业务接口时同时携带：

```http
X-API-Key: app-secret
Authorization: Bearer user-access-token
```

`/api/open/*` 不再接受站内登录态 JWT。

如经运营批准接入 GM 积分账本，运维另行通过 `hdhive openapi-service-credential create --client-id <client_id> --scope points_ledger` 创建服务凭证。原始密钥只在创建/轮换时显示一次；轮换和撤销同样按 `client_id + scope` 操作。该凭证不得发送到浏览器。

## 文档索引

- [认证与授权](authentication.md)：应用 Secret、用户 Token、授权页参数、回调模式、scope。
- [接口列表](endpoints.md)：OAuth 接口和 `/api/open/*` 业务接口。
- [通用响应格式](response-format.md)：成功响应、错误响应、错误码和 429 退避字段。
- [OpenAPI 应用等级](openapi-app-tiers.md)：A/B/C 等级、IP 策略、用户等级、QPS 和冷却配置。
- [第三方开发者接入指南](third-party-developer-guide.md)：可直接发送给外部接入方的完整接入文档。
- [管理员指南](openapi-admin-guide.md)：后台审核、策略配置和运营管理说明。
- [OAuth Smoke Checklist](oauth-smoke-checklist.md)：本地联调和 smoke 验证清单。

## 迁移说明

历史个人 API Key 的迁移目标是：

- 不再把个人 Key 作为第三方应用凭证。
- 第三方应用使用 OpenAPI 应用 Secret 认证。
- 用户级操作通过 OAuth 用户 Token 明确归属到授权用户。
- 限流和冷却按全局、应用、授权用户和特定解锁行为分层执行。

迁移灰度期默认开启 `allow_legacy_personal_keys` 时，历史个人 Key 可以暂时继续访问 `/api/open/*`，但该模式仅用于兼容，不应写入新接入文档或 SDK 示例。

## 维护原则

1. `/api/open/*` 路由以 `app/server/routes/open/open_routes.go` 为准。
2. OAuth 路由以 `app/server/routes/public/public.go` 中 `/api/public/openapi/oauth/*` 为准。
3. 应用认证、用户身份、个人 Key 兼容、VIP 校验以 `app/middleware/open_api_auth.go` 为准。
4. scope、IP 策略、应用/用户 QPS 和冷却以 `app/service/openapi_access_service.go` 与 `openapi_access_config` 为准。
5. 文档不公开具体生产 QPS 阈值。接入方应按 `429`、`Retry-After`、`limit_scope` 和 `retry_after_seconds` 进行退避。
