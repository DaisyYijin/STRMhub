# 通用响应格式

OpenAPI 接口返回 JSON。响应体统一包含 `success`、`code`、`message`，成功时通常包含 `data`，分页或统计信息放在 `meta`。

## 成功响应

```json
{
  "success": true,
  "code": "200",
  "message": "success",
  "data": {
    "message": "pong"
  },
  "meta": null
}
```

| 字段 | 类型 | 说明 |
|---|---|---|
| `success` | boolean | 固定为 `true` |
| `code` | string | 成功时为 `"200"` |
| `message` | string | `success` 或业务成功消息 |
| `data` | object / array / null | 响应数据 |
| `meta` | object / null | 分页、统计、总数等元信息 |

## 错误响应

```json
{
  "success": false,
  "code": "SCOPE_NOT_ALLOWED",
  "message": "Scope is not allowed",
  "description": "该应用未授权调用 unlock 接口组"
}
```

| 字段 | 类型 | 说明 |
|---|---|---|
| `success` | boolean | 固定为 `false` |
| `code` | string | HTTP 状态码字符串或 OpenAPI 业务错误码 |
| `message` | string | 错误摘要 |
| `description` | string | 面向开发者或用户的详细说明 |
| `data` | object / null | 少数错误会附加结构化数据 |

## 429 退避字段

限流、冷却或全局流量保护触发时，HTTP 状态码为 `429`，并尽量返回 `Retry-After` Header。

```http
HTTP/1.1 429 Too Many Requests
Retry-After: 300
```

```json
{
  "success": false,
  "code": "USER_RATE_LIMIT_EXCEEDED",
  "message": "User OpenAPI rate limit exceeded",
  "description": "用户 OpenAPI 请求频率过高，当前授权用户已进入冷却，请稍后重试",
  "limit_scope": "user",
  "limit_scope_label": "授权用户",
  "retry_after_seconds": 300
}
```

| 字段 | 类型 | 说明 |
|---|---|---|
| `Retry-After` | header | 建议等待秒数 |
| `retry_after_seconds` | integer | 与 `Retry-After` 对齐的等待秒数 |
| `limit_scope` | string | 限制对象，可能为 `global`、`app`、`user` |
| `limit_scope_label` | string | 限制对象中文说明 |

客户端必须按 `Retry-After` 退避。`limit_scope=app` 表示应用整体受限；`limit_scope=user` 表示当前授权用户受限；`limit_scope=global` 表示平台全局流量保护。

## 认证错误

| 错误码 | HTTP 状态码 | 说明 |
|---|---|---|
| `MISSING_API_KEY` | 401 | 未提供 `X-API-Key` |
| `INVALID_API_KEY` | 401 | API Key 无效或凭证类型不允许访问 |
| `DISABLED_API_KEY` | 401 | API Key 已被禁用 |
| `EXPIRED_API_KEY` | 401 | API Key 已过期 |
| `INVALID_OPENAPI_USER_TOKEN` | 401 | OpenAPI 用户 Token 无效 |
| `OPENAPI_REFRESH_REQUIRED` | 401 | Access Token 已过期，需要调用 Refresh 接口 |
| `OPENAPI_REAUTH_REQUIRED` | 401 | 必须重新发起 OAuth 授权 |
| `USER_NOT_FOUND` | 401 | 用户不存在 |
| `ACCOUNT_BLOCKED` | 403 | 账号已被封禁 |

## OAuth 授权错误

| 错误码 | HTTP 状态码 | 说明 |
|---|---|---|
| `400` | 400 | 参数错误、授权码无效、grant_type 不支持等普通请求错误 |
| `401` | 401 | Token 接口缺少或使用了错误应用 Secret |
| `STATE_REQUIRED` | 400 | 授权请求缺少 `state` |
| `RISK_BLOCKED` | 403 | 当前用户风险状态不允许授权 |
| `USER_TIER_NOT_ALLOWED` | 403 | 当前用户等级不允许授权该应用等级 |
| `503` | 503 | Webhook 授权回调任务提交失败 |

## 访问控制错误

| 错误码 | HTTP 状态码 | 说明 |
|---|---|---|
| `OPENAPI_USER_REQUIRED` | 401 | 业务接口需要 OpenAPI 用户 Access Token |
| `SCOPE_NOT_ALLOWED` | 403 | 应用 scope 不包含目标接口组 |
| `USER_SCOPE_NOT_ALLOWED` | 403 | 用户授权 Token scope 不包含目标接口组 |
| `VIP_REQUIRED` | 403 | 当前用户不满足 Premium 要求 |
| `IP_NOT_ALLOWED` | 403 | 请求 IP 不在应用白名单内，`description` 会包含后端实际识别到的 IP |

## 限流和冷却错误

| 错误码 | HTTP 状态码 | 说明 |
|---|---|---|
| `GLOBAL_RATE_LIMIT_EXCEEDED` | 429 | OpenAPI 全局 QPS 保护触发 |
| `OPENAPI_COOLDOWN` | 429 | 应用或授权用户处于 OpenAPI 冷却期 |
| `APP_RATE_LIMIT_EXCEEDED` | 429 | 应用请求频率过高并进入冷却 |
| `USER_RATE_LIMIT_EXCEEDED` | 429 | 授权用户请求频率过高并进入冷却 |
| `IP_COUNT_EXCEEDED` | 429 | 动态 IP 策略触发唯一 IP 数限制 |
| `RATE_LIMIT_EXCEEDED` | 429 | 用户操作限速触发，常见于解锁行为 |
| `ENDPOINT_QUOTA_EXCEEDED` | 429 | 历史接口配额模型返回的接口额度超限 |
| `QUOTA_EXCEEDED` | 429 | 通用配额超限 |

## 业务错误

| 错误码 | HTTP 状态码 | 说明 |
|---|---|---|
| `400` | 400 | 请求参数错误或业务校验失败 |
| `401` | 401 | 该业务操作缺少用户授权 |
| `403` | 403 | 无权访问 |
| `404` | 404 | 资源、分享或媒体不存在 |
| `invalid_params` | 400 | 请求参数不符合接口约束，常见于流媒体榜单和追剧日历查询 |
| `INSUFFICIENT_POINTS` | 402 | 当前用户积分不足，无法解锁资源 |
| `502` | 502 | 依赖服务暂时不可用或返回格式无效 |
| `500` | 500 | 服务内部错误 |
| `503` | 503 | 依赖服务或异步任务不可用 |

## 批量解锁 item 级错误

`POST /api/open/resources/unlock` 使用 `slugs` 批量模式时，HTTP 可能仍然返回 `200`，但单个资源的失败会体现在 `data.items[].success=false` 与 `data.items[].error_code` 中。

| item 级错误码 | 说明 |
|---|---|
| `RESOURCE_NOT_FOUND` | 找不到该资源 |
| `INSUFFICIENT_POINTS` | 当前用户积分不足 |
| `UNLOCK_FAILED` | 其他解锁失败 |

## 响应处理建议

1. 先按 HTTP 状态码区分成功、参数错误、认证错误、权限错误、限流和服务错误。
2. 对 `401` 认证错误，不要盲目重试，应检查应用 Secret 或用户 Token。
3. 对 `403` scope、VIP 或用户等级错误，应调整应用申请、用户授权或业务展示。
4. 对 `429` 必须读取 `Retry-After`，并结合 `limit_scope` 做应用级或用户级退避。
5. 对 `500` 和 `503` 可做有限次数指数退避重试，并记录 `code`、`message`、`description` 便于排查。
