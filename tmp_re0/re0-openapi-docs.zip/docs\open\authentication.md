# 认证与授权

RE0 OpenAPI 使用“应用认证 + 用户授权”的双层模型。应用 Secret 证明调用方是谁，OpenAPI 用户 Access Token 证明调用方代表哪个 RE0 用户执行操作。

## 凭证类型

| 凭证 | 用途 | 暴露范围 |
|---|---|---|
| `client_id` | 公开应用 ID，用于授权页识别应用 | 可出现在浏览器和授权链接中 |
| 应用 Secret | OpenAPI 应用密钥，通过 `X-API-Key` 发送 | 只能保存在第三方服务端 |
| OpenAPI 用户 Access Token | 代表用户调用业务接口 | 仅在可信后端或安全客户端中使用 |
| OpenAPI Refresh Token | 刷新用户 Access Token | 只能保存在第三方服务端 |

## X-API-Key 应用认证

所有 `/api/open/*` 业务接口必须携带 `X-API-Key`：

```http
X-API-Key: app-secret
```

服务端会校验：

1. Secret 是否存在且有效。
2. 应用是否启用、未过期。
3. 凭证类型是否为已审核通过的 `openapi_app`。
4. 如果是历史 `personal_key`，仅在 `allow_legacy_personal_keys=true` 的迁移灰度期临时放行。
5. 应用所属账号是否被封禁。

OAuth 的 Token、Refresh 和 Revoke 接口同样使用应用 Secret：

```http
POST /api/public/openapi/oauth/token
POST /api/public/openapi/oauth/refresh
X-API-Key: app-secret
Content-Type: application/json
```

## 用户身份识别顺序

非 `meta` 类业务接口必须能确定当前用户。服务端按以下顺序识别用户：

1. `Authorization: Bearer <OpenAPI user access token>`：唯一可接受的业务用户令牌。Token 必须属于当前 `X-API-Key` 对应的 OpenAPI 应用。
2. 站内用户 JWT 与 API Key 绑定用户兜底都不再适用于 `/api/open/*` 业务接口。

如果目标接口组不是 `meta` 且无法确定用户，返回 `OPENAPI_USER_REQUIRED`（401）。

## OAuth 授权流程

第三方应用应使用前端授权页发起用户授权：

```text
https://re0.me/openapi/authorize?client_id=app_xxx&redirect_uri=https%3A%2F%2Fclient.example.com%2Fcallback&scope=query%20unlock&state=opaque-state
```

完整流程：

1. 第三方应用生成不可预测的 `state`，并把用户跳转到 `/openapi/authorize`。
2. HDHive 授权页要求用户登录。
3. 授权页调用 `GET /api/public/openapi/oauth/authorize` 获取应用和授权信息。
4. 用户确认授权后，授权页调用 `POST /api/public/openapi/oauth/authorize` 生成一次性授权码。
5. 授权页根据应用固定的 `callback_mode` 回传授权结果。
6. 第三方服务端使用应用 Secret 调用 `POST /api/public/openapi/oauth/token` 换取用户 Token。
7. Access Token 过期时，第三方服务端使用 `POST /api/public/openapi/oauth/refresh` 刷新。
8. 第三方应用调用 `/api/open/*` 时同时携带应用 Secret 和用户 Access Token。

## 授权页参数

| 参数 | 必填 | 说明 |
|---|---|---|
| `client_id` | 是 | OpenAPI 应用公开 ID，不是应用 Secret |
| `redirect_uri` | 是 | 授权完成后的回调地址，必须是完整 `http` 或 `https` URL，不能包含 fragment |
| `scope` | 否 | 请求的用户授权 scope，空格分隔，例如 `query unlock` |
| `state` | 是 | 第三方应用生成的状态值，用于防 CSRF 和恢复业务上下文 |
| `response_mode` | 否 | 可传 `redirect`、`postmessage` 或 `webhook`，必须与应用固定回调模式一致 |

缺少 `state` 时授权页会阻止继续授权，后端返回 `STATE_REQUIRED`。

## 回调模式

OpenAPI 应用创建时固定一种回调模式。

| 模式 | 授权结果回传方式 | 适用场景 |
|---|---|---|
| `redirect` | 浏览器跳转到 `redirect_uri?code=...&state=...` | 常规 Web 服务端应用 |
| `postmessage` | 授权弹窗通过 `window.opener.postMessage` 回传授权结果 | 桌面端、单页应用的弹窗授权体验 |
| `webhook` | HDHive 服务端将授权码 POST 到应用配置的 `webhook_url`，浏览器跳回 `redirect_uri?ok=1&state=...` | 需要服务端异步接收授权结果的应用 |

`postmessage` 模式在没有 `window.opener` 时，前端会降级为 redirect。`webhook` 模式要求应用配置有效的 `webhook_url`，并妥善校验平台签名。

## Token 接口

### 授权码换 Token

```bash
curl -X POST https://re0.me/api/public/openapi/oauth/token \
  -H "X-API-Key: app-secret" \
  -H "Content-Type: application/json" \
  -d '{
    "grant_type": "authorization_code",
    "code": "authorization-code",
    "redirect_uri": "https://client.example.com/callback"
  }'
```

`redirect_uri` 是授权码安全校验字段，必须与创建授权码时传入的地址完全一致，不会触发跳转。

### 刷新 Token

```bash
curl -X POST https://re0.me/api/public/openapi/oauth/refresh \
  -H "X-API-Key: app-secret" \
  -H "Content-Type: application/json" \
  -d '{
    "refresh_token": "refresh-token"
  }'
```

### 撤销 Refresh Token

```bash
curl -X POST https://re0.me/api/public/openapi/oauth/revoke \
  -H "X-API-Key: app-secret" \
  -H "Content-Type: application/json" \
  -d '{"refresh_token": "refresh-token"}'
```

## Scope

| scope | 说明 |
|---|---|
| `meta` | 健康检查、配额和用量查询 |
| `query` | 资源查询、资源文件列表预览、分享和追更详情、流媒体榜单、追剧日历、资源链接检查、当前授权用户基础信息 |
| `unlock` | 单个或批量解锁普通资源，以及解锁追更包 |
| `points` | 扣除/退回积分（第三方内购） |
| `write` | 创建、更新、删除分享和追更包，维护追更资源，查看我的分享，每日签到 |
| `vip` | Premium 用户权益摘要、长期 Premium 每周免费解锁状态 |
| `subscription` | 创建、查询、检查和取消作者、媒体资源、片单及已解锁追更包订阅 |
| `messages` | 查询站内信、获取未读数、标记已读和删除已读站内信 |

应用 scope 存储在应用配置中。用户 Token 如果带有 scope 限制，也会参与校验。应用 scope 或用户 scope 不足分别返回 `SCOPE_NOT_ALLOWED` 或 `USER_SCOPE_NOT_ALLOWED`。

`/api/open/resources/unlock` 兼容旧版单个 `slug` 请求，也支持 `slugs` 批量请求；当 `slugs` 非空时会按批量模式处理。

订阅接口接受 `publisher`、`media_resource`、`playlist` 和 `tv_follow` 目标。`tv_follow` 只能订阅当前用户已解锁的追更包；解锁和订阅通知是两个独立状态。

`/api/open/tv-follow/*` 按实际操作拆分 scope：读取使用 `query`，发布与维护使用 `write`，解锁使用 `unlock`。资源批量新增单次最多 500 条。

## 认证与授权错误

| 错误码 | HTTP 状态码 | 说明 |
|---|---|---|
| `MISSING_API_KEY` | 401 | 未提供 `X-API-Key` |
| `INVALID_API_KEY` | 401 | API Key 无效、不是已审核 OpenAPI 应用，或旧个人 Key 不再允许访问 |
| `DISABLED_API_KEY` | 401 | 应用 Secret 已被禁用 |
| `EXPIRED_API_KEY` | 401 | 应用 Secret 已过期 |
| `INVALID_OPENAPI_USER_TOKEN` | 401 | OpenAPI 用户 Access Token 无效 |
| `OPENAPI_REFRESH_REQUIRED` | 401 | Access Token 已过期，需要调用 Refresh 接口 |
| `OPENAPI_REAUTH_REQUIRED` | 401 | 必须重新发起 OAuth 授权 |
| `USER_NOT_FOUND` | 401 | Token 对应用户不存在 |
| `ACCOUNT_BLOCKED` | 403 | 应用所属用户或当前授权用户已被封禁 |
| `OPENAPI_USER_REQUIRED` | 401 | 业务接口缺少 OpenAPI 用户身份 |
| `SCOPE_NOT_ALLOWED` | 403 | 应用未授权目标接口组 |
| `USER_SCOPE_NOT_ALLOWED` | 403 | 用户授权 scope 不足 |
| `VIP_REQUIRED` | 403 | 当前用户不满足 Premium 要求 |
| `STATE_REQUIRED` | 400 | OAuth 授权请求缺少 `state` |
| `RISK_BLOCKED` | 403 | 当前用户风险状态不允许授权第三方应用 |
| `USER_TIER_NOT_ALLOWED` | 403 | 当前用户等级不允许授权该应用等级 |
