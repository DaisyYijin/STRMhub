# OpenAPI 接口列表

本文档列出当前公开 OpenAPI 接口。生产环境示例域名为 `https://re0.me`。

## 总览

OpenAPI 分两类：

| 类型 | 前缀 | 说明 |
|---|---|---|
| 用户授权接口 | `/api/public/openapi/oauth` | 授权预览、确认授权、换取 Token、刷新 Token、撤销 Refresh Token |
| 业务接口 | `/api/open` | 资源查询、解锁、积分内购、分享管理、订阅、站内信、用户信息、签到、用量查询 |
| GM 合作方内部接口 | `/api/internal/openapi` | 双凭证保护的积分账本和应用自检；不属于公开 OAuth 业务接口 |

业务接口都需要：

```http
X-API-Key: app-secret
```

除 `meta` 接口外，业务接口必须同时携带 OpenAPI 用户 Access Token；站内登录态 JWT 不再适用于 `/api/open/*`：

```http
Authorization: Bearer user-access-token
```

## GM 合作方积分账本（service-only）

以下接口仅供获批的 A 级合作方服务端和 GM 系统联调。它们不接受 `X-API-Key` 应用 Secret，也不接受通用 `/api/internal` Key。每次请求必须同时携带：

```http
X-Internal-API-Key: gm-ledger-audience-key
X-Partner-Service-Key: one-time-issued-partner-service-key
```

- `X-Internal-API-Key` 只从 `HDHIVE_GM_LEDGER_INTERNAL_KEYS_FILE` 指向的独立密钥环读取，key 的 `audience` 必须为 `gm-ledger`，secret 至少 32 字节；密钥 ID 和 secret 都必须唯一。
- `X-Partner-Service-Key` 绑定唯一父 OpenAPI 应用，可独立轮换、撤销和过期。父应用必须仍为已审核、启用、A 级，并配置 `points_ledger`。
- 读取某个用户前，父应用与该用户之间还必须存在 active、未撤销且包含既有 `points` scope 的 OAuth grant，并继续满足应用用户 audience。grant 本身永远不包含 `points_ledger`。
- `points_ledger` 显式用于 OAuth `scope` 参数会返回 `400`；空 OAuth scope 也会自动过滤该 service-only scope。

账本/游标密钥环示例（真实 secret 应由 secret volume 挂载，不能提交仓库）：

```json
{
  "keys": [
    {"id": "gm-ledger-2026-01", "secret": "<random-secret>", "audience": "gm-ledger", "status": "active"}
  ]
}
```

`HDHIVE_LEDGER_CURSOR_KEYS_FILE` 指向另一个至少 32 字节 HMAC 密钥环：

```json
{
  "active_key_id": "cursor-2026-01",
  "keys": [
    {"id": "cursor-2026-01", "secret": "<at-least-32-random-bytes>", "status": "active"}
  ]
}
```

### GET /api/internal/openapi/points-ledger/users/:user_id

| 参数 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `user_id` | decimal string | 是 | 目标 HDHive 用户 ID |
| `limit` | integer | 否 | 默认 50，范围 1-100；后续页可省略，若提供则必须与首个游标一致 |
| `cursor` | string | 否 | 服务端 HMAC 签名的不透明快照游标；不要解析或修改 |

首个请求会锁定用户积分快照与当时最大的流水 ID。后续新增流水不会漂移到该快照中；游标绑定父应用、用户、最大流水 ID、翻页边界、当前积分、下一页运行余额、页大小和过期时间。篡改、过期、跨应用/跨用户复用或修改页大小均返回 `400`。

响应中的所有 ID 和积分数值均为十进制字符串。余额无法可靠推导（例如缺少用户积分元数据、int64 溢出或快照不一致）时返回 `balance_after: null` 和 `balance_status: "unavailable"`，绝不伪造 `0`。`transaction` 只在流水属于当前父应用时出现，不会泄漏其他应用的交易元数据。

```json
{
  "success": true,
  "code": "200",
  "message": "success",
  "data": {
    "user_id": "42",
    "current_points": "10000",
    "current_points_status": "available",
    "snapshot_max_id": "9182",
    "snapshot_at": "2026-07-13T10:00:00Z",
    "items": [
      {
        "id": "9182",
        "user_id": "42",
        "delta": "-100",
        "change_type": "openapi_purchase",
        "remark": "购买道具",
        "balance_after": "10000",
        "balance_status": "derived",
        "transaction": {
          "id": "301",
          "idempotency_key": "purchase-001",
          "external_ref": "item-7",
          "direction": "debit",
          "status": "succeeded"
        },
        "created_at": "2026-07-13T10:00:00Z",
        "updated_at": "2026-07-13T10:00:00Z"
      }
    ],
    "next_cursor": "opaque.hmac.cursor"
  }
}
```

### GET /api/internal/openapi/apps/self

使用相同双凭证，返回当前服务凭证父应用的最小自检信息：`client_id`、`auth_level`、`review_status`、`is_active`、`scopes`、`require_pkce`。不会返回数据库 ID、用户绑定、Key 前缀、hash 或任何 secret。

服务凭证运维命令：

```bash
hdhive openapi-service-credential create --client-id <client_id> --scope points_ledger
hdhive openapi-service-credential rotate --client-id <client_id> --scope points_ledger
hdhive openapi-service-credential revoke --client-id <client_id> --scope points_ledger
```

原始 `service_key` 只在 create/rotate 成功输出中出现一次，应立即存入 secret manager。

## 用户授权接口

| 方法 | 路径 | 认证 | 说明 |
|---|---|---|---|
| GET | `/api/public/openapi/oauth/authorize` | HDHive 登录 Cookie | 获取授权页展示信息 |
| POST | `/api/public/openapi/oauth/authorize` | HDHive 登录 Cookie | 用户确认授权并生成授权码 |
| POST | `/api/public/openapi/oauth/token` | `X-API-Key` 应用 Secret | 授权码换取用户 Token |
| POST | `/api/public/openapi/oauth/refresh` | `X-API-Key` 应用 Secret | 使用 Refresh Token 刷新用户 Token |
| POST | `/api/public/openapi/oauth/revoke` | `X-API-Key` 应用 Secret | 撤销 Refresh Token |

## 业务接口

| scope | 方法 | 路径 | 说明 |
|---|---|---|---|
| `meta` | GET | `/api/open/ping` | 验证应用 Secret |
| `meta` | GET | `/api/open/quota` | 查询当前应用配额状态 |
| `meta` | GET | `/api/open/usage` | 查询历史用量统计 |
| `meta` | GET | `/api/open/usage/today` | 查询今日用量统计 |
| `query` | GET | `/api/open/resources/:type/:tmdb_id` | 根据 TMDB ID 获取资源列表 |
| `query` | GET | `/api/open/resources/file-list/:slug` | 根据资源 slug 获取文件列表预览，非 Premium 也可调用 |
| `query` | POST | `/api/open/check/resource` | 检查资源链接网盘类型 |
| `query` | GET | `/api/open/shares/:slug` | 获取分享详情 |
| `query` | GET | `/api/open/streaming-top` | 获取指定平台和地区的电影或剧集榜单 |
| `query` | GET | `/api/open/calendar` | 获取未来 1-31 天的追剧日历 |
| `unlock` | POST | `/api/open/resources/unlock` | 单个或批量解锁资源并获取链接 |
| `write` | GET | `/api/open/shares` | 获取当前用户的分享列表 |
| `write` | POST | `/api/open/shares` | 创建分享 |
| `write` | PATCH | `/api/open/shares/:slug` | 更新分享 |
| `write` | DELETE | `/api/open/shares/:slug` | 删除分享 |
| `subscription` | GET | `/api/open/subscriptions` | 获取当前用户订阅列表 |
| `subscription` | POST | `/api/open/subscriptions` | 订阅作者、媒体资源、片单或已解锁追更包 |
| `subscription` | GET | `/api/open/subscriptions/check` | 检查订阅状态 |
| `subscription` | DELETE | `/api/open/subscriptions/:id` | 取消订阅 |
| `query` | GET | `/api/open/tv-follow/packs` | 按剧集查询追更包 |
| `write` | POST | `/api/open/tv-follow/packs` | 创建追更包 |
| `query` | GET | `/api/open/tv-follow/packs/:slug` | 获取追更包详情和解锁状态 |
| `write` | PATCH | `/api/open/tv-follow/packs/:slug` | 更新自己发布的追更包 |
| `write` | DELETE | `/api/open/tv-follow/packs/:slug` | 删除自己发布的追更包 |
| `unlock` | POST | `/api/open/tv-follow/packs/:slug/unlock` | 解锁追更资源，可选择订阅更新 |
| `query` | GET | `/api/open/tv-follow/packs/:slug/items` | 获取已解锁追更包资源，最新季集优先 |
| `write` | POST | `/api/open/tv-follow/packs/:slug/items` | 批量新增追更资源，最多 500 条 |
| `write` | PATCH | `/api/open/tv-follow/items/:id` | 更新自己发布的追更资源 |
| `write` | DELETE | `/api/open/tv-follow/items/:id` | 删除自己发布的追更资源 |
| `query` | GET | `/api/open/tv-follow/my` | 获取当前用户已解锁追更包 |
| `messages` | GET | `/api/open/messages` | 获取当前用户站内信列表 |
| `messages` | GET | `/api/open/messages/unread-count` | 获取当前用户站内信未读数 |
| `messages` | POST | `/api/open/messages/:id/read` | 标记单条站内信已读 |
| `messages` | POST | `/api/open/messages/read` | 批量标记站内信已读 |
| `messages` | POST | `/api/open/messages/read-all` | 标记全部或指定分类站内信已读 |
| `messages` | DELETE | `/api/open/messages/read` | 删除当前用户已读站内信 |
| `write` | POST | `/api/open/checkin` | 当前用户每日签到 |
| `points` | POST | `/api/open/points/debit` | 扣除当前用户积分（第三方内购） |
| `points` | POST | `/api/open/points/refund` | 按原扣费交易全额退回积分 |
| `query` | GET | `/api/open/me` | 获取当前授权用户基础信息 |
| `vip` | GET | `/api/open/vip/entitlements` | 查询当前 Premium 用户权益摘要 |
| `vip` | GET | `/api/open/vip/weekly-free-quota` | 查询长期 Premium 每周免费解锁状态 |

## GET /api/public/openapi/oauth/authorize

获取授权页展示信息。该接口需要 HDHive 站内登录 Cookie；未登录时前端授权页会跳转到登录页。

### Query 参数

| 参数 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `client_id` | string | 是 | OpenAPI 应用公开 Client ID |
| `redirect_uri` | string | 是 | 授权完成回调地址，必须是完整 URL |
| `scope` | string | 否 | 请求 scope，空格分隔 |
| `state` | string | 是 | 第三方应用状态值 |
| `response_mode` | string | 否 | `redirect`、`postmessage` 或 `webhook`，必须与应用固定模式一致 |

### 成功响应字段

| 字段 | 类型 | 说明 |
|---|---|---|
| `data.client_id` | string | 应用 Client ID |
| `data.app_name` | string | 应用名称 |
| `data.description` | string | 应用描述 |
| `data.icon_url` | string | 应用图标 |
| `data.auth_level` | string | 应用等级 |
| `data.callback_mode` | string | 应用固定回调模式 |
| `data.webhook_url_masked` | string | Webhook 模式下的脱敏地址 |
| `data.redirect_uri` | string | 本次授权回调地址 |
| `data.state` | string | 原样回显 state |
| `data.requested_scopes` | string[] | 本次请求 scope |
| `data.allowed_scopes` | string[] | 应用允许 scope |
| `data.user` | object | 当前登录用户摘要 |
| `data.expires_in` | integer | 授权码有效期秒数 |

## POST /api/public/openapi/oauth/authorize

用户确认授权并生成一次性授权码。该接口由 HDHive 授权页调用，第三方应用通常不直接调用。

### Body 参数

| 参数 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `client_id` | string | 是 | OpenAPI 应用公开 Client ID |
| `redirect_uri` | string | 是 | 授权完成回调地址 |
| `scope` | string | 否 | 请求 scope，空格分隔 |
| `state` | string | 是 | 第三方应用状态值 |
| `response_mode` | string | 否 | 期望回调模式，必须与应用固定模式一致 |

### 成功响应

```json
{
  "success": true,
  "code": "200",
  "message": "success",
  "data": {
    "code": "authorization-code",
    "response_mode": "redirect",
    "redirect_uri": "https://client.example.com/callback",
    "expires_in": 600
  }
}
```

HDHive 前端会根据 `response_mode` 完成 redirect、postMessage 或 webhook 回传。

## POST /api/public/openapi/oauth/token

使用授权码换取 OpenAPI 用户 Token。

### Header

```http
X-API-Key: app-secret
Content-Type: application/json
```

### authorization_code Body

| 参数 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `grant_type` | string | 是 | 固定为 `authorization_code` |
| `code` | string | 是 | 一次性授权码 |
| `redirect_uri` | string | 是 | 必须与创建授权码时的 `redirect_uri` 完全一致 |

### 请求示例

```bash
curl -X POST https://re0.me/api/public/openapi/oauth/token \
  -H "X-API-Key: app-secret" \
  -H "Content-Type: application/json" \
  -d '{
    "grant_type": "authorization_code",
    "code": "authorization-code",
    "redirect_uri": "https://client.example.com/callback"
  }'
```

### 成功响应字段

| 字段 | 类型 | 说明 |
|---|---|---|
| `data.access_token` | string | OpenAPI 用户 Access Token |
| `data.refresh_token` | string | Refresh Token |
| `data.token_type` | string | 固定为 `Bearer` |
| `data.expires_in` | integer | Access Token 有效期秒数 |
| `data.refresh_expires_in` | integer | Refresh Token 有效期秒数 |
| `data.scope` | string | 空格分隔 scope |
| `data.scopes` | string[] | scope 数组 |

## POST /api/public/openapi/oauth/refresh

使用 Refresh Token 刷新 OpenAPI 用户 Token。

### Header

```http
X-API-Key: app-secret
Content-Type: application/json
```

### Body 参数

| 参数 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `refresh_token` | string | 是 | Refresh Token |

### 说明

- Access Token 过期后，业务接口会返回 `OPENAPI_REFRESH_REQUIRED`。
- Refresh Token 无效、已撤销、已过期，或授权用户/应用状态变化时，会返回 `OPENAPI_REAUTH_REQUIRED`，此时应重新发起 OAuth 授权。

## POST /api/public/openapi/oauth/revoke

撤销 Refresh Token。撤销后该 Refresh Token 不能再换取新的用户 Access Token。

### Header

```http
X-API-Key: app-secret
Content-Type: application/json
```

### Body 参数

| 参数 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `refresh_token` | string | 是 | 要撤销的 Refresh Token |

### 请求示例

```bash
curl -X POST https://re0.me/api/public/openapi/oauth/revoke \
  -H "X-API-Key: app-secret" \
  -H "Content-Type: application/json" \
  -d '{"refresh_token":"refresh-token"}'
```

## GET /api/open/ping

验证应用 Secret 是否有效。

### 认证

```http
X-API-Key: app-secret
```

### 请求示例

```bash
curl -H "X-API-Key: app-secret" https://re0.me/api/open/ping
```

### 成功响应

```json
{
  "success": true,
  "code": "200",
  "message": "success",
  "data": {
    "message": "pong",
    "api_key_id": 1,
    "name": "My OpenAPI App"
  }
}
```

## GET /api/open/quota

查询当前应用在服务端看到的配额状态。具体生产阈值以服务端配置为准，客户端不应写死。

### 认证

```http
X-API-Key: app-secret
```

### 响应字段

| 字段 | 类型 | 说明 |
|---|---|---|
| `data.daily_reset` | integer | 日配额重置时间戳 |
| `data.endpoint_limit` | integer / null | 当前接口配额限制，未配置时为空 |
| `data.endpoint_remaining` | integer / null | 当前接口剩余配额，未配置时为空 |

## GET /api/open/usage

查询当前应用的历史用量统计。

### Query 参数

| 参数 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `start_date` | string | 否 | 开始日期，格式 `YYYY-MM-DD` |
| `end_date` | string | 否 | 结束日期，格式 `YYYY-MM-DD` |

### 请求示例

```bash
curl -H "X-API-Key: app-secret" \
  "https://re0.me/api/open/usage?start_date=2026-05-01&end_date=2026-05-19"
```

### 响应字段

| 字段 | 类型 | 说明 |
|---|---|---|
| `data.daily_stats` | array | 每日调用统计 |
| `data.endpoint_stats` | array | 按接口聚合统计 |
| `data.summary` | object | 汇总统计 |

## GET /api/open/usage/today

查询当前应用今日用量。

### 响应字段

| 字段 | 类型 | 说明 |
|---|---|---|
| `data.total_calls` | integer | 总调用次数 |
| `data.success_calls` | integer | 成功调用次数 |
| `data.failed_calls` | integer | 失败调用次数 |
| `data.avg_latency` | number | 平均耗时 |

## GET /api/open/resources/:type/:tmdb_id

根据媒体类型和 TMDB ID 获取资源列表。

### 认证与权限

| 项 | 要求 |
|---|---|
| Header | `X-API-Key`、`Authorization: Bearer <user-access-token>` |
| 用户身份 | 必须 |
| scope | `query` |

### Path 参数

| 参数 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `type` | string | 是 | `movie` 或 `tv` |
| `tmdb_id` | string | 是 | TMDB ID |

### 请求示例

```bash
curl -H "X-API-Key: app-secret" \
  -H "Authorization: Bearer user-access-token" \
  https://re0.me/api/open/resources/movie/550
```

### 响应字段

| 字段 | 类型 | 说明 |
|---|---|---|
| `data[].slug` | string | 资源 slug，无横杠 UUID |
| `data[].title` | string / null | 资源标题 |
| `data[].pan_type` | string / null | 网盘类型 |
| `data[].media_url` | string | 站内媒体详情 URL |
| `data[].media_slug` | string | 媒体 slug |
| `data[].share_size` | string / null | 分享大小 |
| `data[].video_resolution` | string[] | 分辨率 |
| `data[].source` | string[] | 片源 |
| `data[].subtitle_language` | string[] | 字幕语言 |
| `data[].subtitle_type` | string[] | 字幕类型 |
| `data[].unlock_points` | integer / null | 解锁积分 |
| `data[].is_unlocked` | boolean | 当前用户是否已解锁 |
| `data[].user` | object / null | 分享者摘要 |
| `data[].created_at` | string | 创建时间 |
| `data[].updated_at` | string | 更新时间 |
| `meta.total` | integer | 返回数量 |

## GET /api/open/resources/file-list/:slug

根据资源 slug 获取网盘文件列表预览。该接口不要求 Premium，也不要求当前用户已解锁该资源；响应只包含文件名、路径、大小等展示字段，不返回分享链接或提取码。需要下载链接时仍应调用 `/api/open/resources/unlock`。

### 认证与权限

| 项 | 要求 |
|---|---|
| Header | `X-API-Key`、`Authorization: Bearer <user-access-token>` |
| 用户身份 | 必须 |
| scope | `query` |
| 用户要求 | 无 |

### Path 参数

| 参数 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `slug` | string | 是 | 资源 slug，支持带横杠或不带横杠 UUID |

### Query 参数

| 参数 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `refresh` | string | 否 | `1` / `true` / `yes` 时跳过 Redis 缓存并重新检测、拉取文件列表 |

成功预览默认缓存 12 小时；检测为无效的空列表缓存 5 分钟。拉取失败不写缓存。解锁页首次加载走缓存，点击刷新会带 `refresh=1`。Customer 与 OpenAPI 共用同一份缓存，key 不含分享链或提取码明文。

### 请求示例

```bash
curl -H "X-API-Key: app-secret" \
  -H "Authorization: Bearer user-access-token" \
  https://re0.me/api/open/resources/file-list/a1b2c3d4e5f647898765432112345678
```

### 响应字段

| 字段 | 类型 | 说明 |
|---|---|---|
| `data.provider` | string | 网盘类型，例如 `115`、`123`、`189`、`guangYa` |
| `data.list_type` | string | 列表类型，通常为 `files` |
| `data.share_title` | string | 分享标题 |
| `data.share_state` | integer | 分享状态码 |
| `data.share_state_label` | string | 分享状态说明 |
| `data.file_count` | integer | 文件数量 |
| `data.result_type` | string | `files` 或 `validation` |
| `data.files[].name` | string | 文件名 |
| `data.files[].path` | string | 文件路径 |
| `data.files[].size` | integer | 文件大小（字节） |
| `data.files[].extension` | string | 扩展名 |
| `data.resource_validate_status` | string / omitted | 资源检测状态 |
| `data.resource_validate_message` | string / omitted | 资源检测说明 |

资源检测为无效时，接口仍返回 `200`，`data.files` 为空，`data.result_type` 为 `validation`。文件列表功能未启用时返回 `503`；当前网盘未开放预览时返回 `400`。

## POST /api/open/resources/unlock

代表当前用户单个或批量解锁资源并获取链接。

### 认证与权限

| 项 | 要求 |
|---|---|
| Header | `X-API-Key`、`Authorization: Bearer <user-access-token>` |
| 用户身份 | 必须 |
| scope | `unlock` |

### Body 参数

| 参数 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `slug` | string | 否 | 单个资源 slug，兼容旧版调用 |
| `slugs` | string[] | 否 | 批量资源 slug 列表，支持带横杠或不带横杠 UUID |

说明：

- 至少提供一个资源标识。
- 当 `slugs` 非空时，服务端进入批量模式，并把 `slug` 与 `slugs` 合并去重后按出现顺序处理。
- 批量响应中的 `data.items[].slug` 会返回规范化后的 UUID 字符串。

### 批量解锁限制

- 普通用户：单次最多 1 个资源。
- 普通 VIP：单次最多 5 个资源。
- 长期 VIP：单次最多 10 个资源。
- 一次批量请求无论包含多少个资源，都只计 1 次解锁 QPS。

### 请求示例

```bash
curl -X POST https://re0.me/api/open/resources/unlock \
  -H "X-API-Key: app-secret" \
  -H "Authorization: Bearer user-access-token" \
  -H "Content-Type: application/json" \
  -d '{"slug":"a1b2c3d4e5f647898765432112345678"}'
```

```bash
curl -X POST https://re0.me/api/open/resources/unlock \
  -H "X-API-Key: app-secret" \
  -H "Authorization: Bearer user-access-token" \
  -H "Content-Type: application/json" \
  -d '{"slugs":["a1b2c3d4e5f647898765432112345678","b2c3d4e5f64789876543211234567890"]}'
```

### 成功响应

```json
{
  "success": true,
  "code": "200",
  "message": "解锁成功",
  "data": {
    "url": "https://pan.example.com/s/abc123",
    "access_code": "x1y2",
    "full_url": "https://pan.example.com/s/abc123?pwd=x1y2",
    "already_owned": false
  }
}
```

当 ED2K SIZE 水印开关开启且返回值包含 ED2K 文件链接时，服务端会按当前用户把混淆标识直接写入数字 `SIZE`，不会附加自定义扩展字段；MD4 哈希保持不变。该链接面向只校验哈希的 115 离线流程，返回的 `SIZE` 不再代表文件真实字节数，也不应作为标准 eMule/aMule 文件身份使用。即使文件名被重命名或尾部可选字段被删除，管理员仍可从水印 `SIZE` 反查用户。管理员关闭开关后，新返回的链接保留原始真实 `SIZE`；已发出的历史水印仍可反查。

批量请求会返回：

- `data.items[].slug`
- `data.items[].success`
- `data.items[].message`
- `data.items[].error_code`
- `data.items[].url`
- `data.items[].access_code`
- `data.items[].full_url`
- `data.items[].already_owned`
- `data.total`
- `data.success_count`
- `data.failed_count`

批量响应示例：

```json
{
  "success": true,
  "code": "200",
  "message": "批量解锁完成，成功 1 个，失败 1 个",
  "data": {
    "items": [
      {
        "slug": "a1b2c3d4-e5f6-4789-8765-432112345678",
        "success": true,
        "message": "解锁成功",
        "url": "https://pan.example.com/s/abc123",
        "access_code": "x1y2",
        "full_url": "https://pan.example.com/s/abc123?pwd=x1y2",
        "already_owned": false
      },
      {
        "slug": "b2c3d4e5-f647-4898-8765-432112345678",
        "success": false,
        "message": "积分不足",
        "error_code": "INSUFFICIENT_POINTS",
        "already_owned": false
      }
    ],
    "total": 2,
    "success_count": 1,
    "failed_count": 1
  }
}
```

批量解锁 `data.items[].error_code`：

| 值 | 说明 |
|---|---|
| `RESOURCE_NOT_FOUND` | 资源不存在 |
| `INSUFFICIENT_POINTS` | 当前用户积分不足 |
| `UNLOCK_FAILED` | 其他解锁失败 |

## POST /api/open/check/resource

检查资源链接所属网盘类型，并尝试解析部分网盘访问码。

### 认证与权限

| 项 | 要求 |
|---|---|
| Header | `X-API-Key`、`Authorization: Bearer <user-access-token>` |
| 用户身份 | 必须 |
| scope | `query` |

### Body 参数

| 参数 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `url` | string | 是 | 资源分享链接 |

### 成功响应字段

| 字段 | 类型 | 说明 |
|---|---|---|
| `data.website` | string | 识别出的网盘类型 |
| `data.url` | string | 规范化后的 URL |
| `data.base_link` | string | 解析出的基础链接 |
| `data.access_code` | string | 解析出的访问码 |
| `data.default_unlock_points` | integer / null | 当前用户默认解锁积分 |

## GET /api/open/me

获取当前授权用户基础信息。需要 `query` scope。

### 认证与权限

| 项 | 要求 |
|---|---|
| Header | `X-API-Key`、`Authorization: Bearer <user-access-token>` |
| 用户身份 | 必须 |
| scope | `query` |
| 用户要求 | 无 |

### 响应字段

| 字段 | 类型 | 说明 |
|---|---|---|
| `data.id` | number | 用户 ID |
| `data.level` | string | 用户等级，可能为 `normal`、`vip`、`forever_vip` |
| `data.username` | string | 用户名 |
| `data.nickname` | string | 昵称 |
| `data.avatar_url` | string | 头像 URL |
| `data.is_blocked` | boolean | 当前授权用户是否已被封禁 |
| `data.checked_in_today` | boolean | 当前授权用户今日是否已签到（北京时间） |
| `data.points` | number | 当前积分总额 |
| `data.signin_days_total` | number | 累计签到天数 |
| `data.share_num` | number | 分享数量 |
| `data.is_forever_vip` | boolean | 是否长期 Premium |
| `data.weekly_free_quota` | number | 每周免费解锁总额度，`0` 表示无限额 |
| `data.weekly_free_quota_remaining` | number | 剩余免费解锁额度，`-1` 表示无限额 |
| `data.weekly_free_quota_unlimited` | boolean | 是否无限额 |
| `data.bonus_quota` | number | 额外奖励额度 |

## GET /api/open/vip/entitlements

查询当前 Premium 用户权益摘要。需要 `vip` scope。

### 认证与权限

| 项 | 要求 |
|---|---|
| Header | `X-API-Key`、`Authorization: Bearer <user-access-token>` |
| 用户身份 | 必须 |
| scope | `vip` |
| 用户要求 | Premium |

### 响应字段

| 字段 | 类型 | 说明 |
|---|---|---|
| `data.level` | string | 用户等级，可能为 `vip`、`forever_vip` |
| `data.is_blocked` | boolean | 当前授权用户是否已被封禁 |
| `data.is_forever_vip` | boolean | 是否长期 Premium |
| `data.weekly_free_quota` | number | 每周免费解锁总额度 |
| `data.weekly_free_quota_remaining` | number | 剩余免费解锁额度 |
| `data.weekly_free_quota_unlimited` | boolean | 是否无限额 |
| `data.bonus_quota` | number | 额外奖励额度 |
| `data.can_use_vip_unlock` | boolean | 当前是否可使用 Premium 解锁权益 |

## POST /api/open/checkin

代表当前授权用户执行每日签到。需要 `write` scope；Premium 用户仍按站内签到规则获得额外积分倍率。

### Body 参数

| 参数 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `is_gambler` | boolean | 否 | 是否使用高波动签到模式 |

### 成功响应

```json
{
  "success": true,
  "code": "200",
  "message": "签到成功，获得 8 积分",
  "data": {
    "checked_in": true,
    "message": "签到成功，获得 8 积分",
    "points": 8
  }
}
```

| 字段 | 类型 | 说明 |
|---|---|---|
| `data.checked_in` | boolean | 本次是否签到成功 |
| `data.message` | string | 签到结果说明 |
| `data.points` | integer | 本次签到获得的积分；已签到时为 `0` |

如果当天已签到，接口仍返回 `200`，`data.checked_in=false`，`data.points=0`，并在 `message` 中说明原因。

```json
{
  "success": true,
  "code": "200",
  "message": "你已经签到过了，明天再来吧",
  "data": {
    "checked_in": false,
    "message": "你已经签到过了，明天再来吧",
    "points": 0
  }
}
```

当前积分总额可通过 `GET /api/open/me` 的 `data.points` 查询。

## POST /api/open/points/debit

代表当前授权用户扣除积分，用于第三方内购。需要 `points` scope。定价由第三方自行决定；HDHive 只按 `amount` 记账。

### 认证与权限

| 项 | 要求 |
|---|---|
| Header | `X-API-Key`、`Authorization: Bearer <user-access-token>` |
| 用户身份 | 必须 |
| scope | `points` |

### Body 参数

| 参数 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `amount` | integer | 是 | 扣除积分数，正整数，上限 `100000` |
| `idempotency_key` | string | 是 | 幂等键，至少 12 字符；同一应用+用户下唯一 |
| `reason` | string | 是 | 扣费原因（展示在积分流水） |
| `external_ref` | string | 否 | 第三方订单号或其他外部引用 |

### 成功响应

```json
{
  "success": true,
  "code": "200",
  "message": "积分扣除成功",
  "data": {
    "transaction_id": 42,
    "amount": 100,
    "remaining_points": 900,
    "duplicate": false
  }
}
```

| 字段 | 类型 | 说明 |
|---|---|---|
| `data.transaction_id` | number | 扣费交易 ID，退款时使用 |
| `data.amount` | integer | 扣除金额 |
| `data.remaining_points` | integer | 扣费后余额 |
| `data.duplicate` | boolean | 是否幂等命中（未重复扣费） |

相同 `(api_key, user, idempotency_key)` 且 `amount`/`external_ref` 一致时返回原结果且 `duplicate=true`。参数冲突返回 `IDEMPOTENCY_CONFLICT`。余额不足返回 `INSUFFICIENT_POINTS`（402）。

## POST /api/open/points/refund

按原扣费交易全额退回积分。需要 `points` scope。首版不支持部分退款。

### 认证与权限

| 项 | 要求 |
|---|---|
| Header | `X-API-Key`、`Authorization: Bearer <user-access-token>` |
| 用户身份 | 必须 |
| scope | `points` |

### Body 参数

| 参数 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `transaction_id` | number | 是 | 原扣费交易 ID |
| `idempotency_key` | string | 是 | 退款幂等键，至少 12 字符 |
| `reason` | string | 是 | 退款原因 |
| `amount` | integer | 否 | 省略则全额退；若传必须等于原扣费金额 |

### 成功响应

```json
{
  "success": true,
  "code": "200",
  "message": "积分退款成功",
  "data": {
    "transaction_id": 99,
    "refunded_transaction_id": 42,
    "amount": 100,
    "remaining_points": 1000,
    "duplicate": false
  }
}
```

| 字段 | 类型 | 说明 |
|---|---|---|
| `data.transaction_id` | number | 退款交易 ID |
| `data.refunded_transaction_id` | number | 被冲正的原扣费交易 ID |
| `data.amount` | integer | 退回金额 |
| `data.remaining_points` | integer | 退款后余额 |
| `data.duplicate` | boolean | 是否幂等命中 |

常见错误：`TRANSACTION_NOT_FOUND`（404）、`TRANSACTION_NOT_REFUNDABLE`（409）、`IDEMPOTENCY_CONFLICT`（409）、`INVALID_AMOUNT`（400）。

## GET /api/open/vip/weekly-free-quota

查询当前用户长期 Premium 每周免费解锁状态。

### 响应字段

| 字段 | 类型 | 说明 |
|---|---|---|
| `data.is_forever_vip` | boolean | 是否长期 Premium |
| `data.limit` | integer | 每周基础额度上限 |
| `data.used` | integer | 本周已使用次数 |
| `data.remaining` | integer | 当前可用总免费次数，`-1` 表示不限 |
| `data.unlimited` | boolean | 是否不限制 |
| `data.bonus_quota` | integer | 当前累积额度 |
| `data.bonus_quota_max` | integer | 累积额度上限 |

## GET /api/open/shares

获取当前授权用户创建的分享列表，包含普通资源和音乐资源。

### 认证与权限

| 项 | 要求 |
|---|---|
| Header | `X-API-Key`、`Authorization: Bearer <user-access-token>` |
| 用户身份 | 必须 |
| scope | `write` |

### Query 参数

| 参数 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `page` | integer | 否 | 页码，默认 1 |
| `page_size` | integer | 否 | 每页数量，默认 20，最大 100 |

### 响应字段

| 字段 | 类型 | 说明 |
|---|---|---|
| `data[].type` | string | `resource` 或 `music` |
| `data[].slug` | string | 分享 slug |
| `data[].title` | string / null | 分享标题 |
| `data[].unlock_points` | integer / null | 解锁积分 |
| `meta.total` | integer | 总数 |
| `meta.page` | integer | 当前页 |
| `meta.page_size` | integer | 每页数量 |

## GET /api/open/shares/:slug

获取指定分享详情。该接口不返回原始下载链接；需要调用 `/api/open/resources/unlock` 解锁后获取。

### Path 参数

| 参数 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `slug` | string | 是 | 分享 slug，支持无横杠 UUID |

### 关键响应字段

| 字段 | 类型 | 说明 |
|---|---|---|
| `data.slug` | string | 分享 slug |
| `data.pan_type` | string / null | 网盘类型 |
| `data.actual_unlock_points` | integer | 当前用户实际解锁积分 |
| `data.is_unlocked` | boolean | 是否已解锁 |
| `data.is_free_for_user` | boolean | 对当前用户是否免费 |
| `data.unlock_message` | string | 解锁提示 |
| `data.media` | object / null | 关联媒体 |
| `data.user` | object / null | 分享者摘要 |
| `data.created_at` | string | 创建时间 |
| `data.updated_at` | string | 更新时间 |

## POST /api/open/shares

创建新的资源分享。

### 认证与权限

| 项 | 要求 |
|---|---|
| Header | `X-API-Key`、`Authorization: Bearer <user-access-token>` |
| 用户身份 | 必须 |
| scope | `write` |

### Body 参数

| 参数 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `url` | string | 是 | 分享链接；115 可直接传带 `password` 参数的完整链接 |
| `tmdb_id` | string | 条件必填 | TMDB ID，需配合 `media_type` |
| `media_type` | string | 条件必填 | `movie` 或 `tv` |
| `movie_id` | integer | 条件必填 | 系统电影 ID |
| `tv_id` | integer | 条件必填 | 系统电视剧 ID |
| `collection_id` | integer | 条件必填 | 系统合集 ID |
| `title` | string | 否 | 分享标题 |
| `share_size` | string | 否 | 资源大小 |
| `video_resolution` | string[] | 否 | 分辨率 |
| `source` | string[] | 否 | 片源 |
| `subtitle_language` | string[] | 否 | 字幕语言 |
| `subtitle_type` | string[] | 否 | 字幕类型 |
| `remark` | string | 否 | 备注 |
| `access_code` | string | 条件必填 | 访问码；115 必须提供，若 `url` 已携带 `password` 参数则服务端自动解析 |
| `subscrip_url` | string | 否 | 订阅链接 |
| `unlock_points` | integer | 否 | 解锁积分，发布范围 0–10 |
| `is_anonymous` | boolean | 否 | 是否匿名分享 |
| `hide_link` | boolean | 否 | 通知时是否隐藏原始链接，默认隐藏 |
| `is_completed` | boolean | 否 | 是否已完结（仅剧集资源） |

影视关联至少提供 `tmdb_id + media_type`、`movie_id`、`tv_id` 或 `collection_id` 之一。

115 分享创建时，服务端优先使用显式传入的非空 `access_code`；未传时会尝试从
`url` 的 `password` 参数或分享文本中的“访问码”字段提取。两处都没有访问码时
请求返回 `400`，避免创建无法访问的分享。

## PATCH /api/open/shares/:slug

部分更新已有分享。只能更新当前用户有权限操作的分享。

### Body 参数

可更新字段：

| 参数 | 类型 | 说明 |
|---|---|---|
| `title` | string | 分享标题 |
| `url` | string | 分享链接 |
| `share_size` | string | 资源大小 |
| `video_resolution` | string[] | 分辨率 |
| `source` | string[] | 片源 |
| `subtitle_language` | string[] | 字幕语言 |
| `subtitle_type` | string[] | 字幕类型 |
| `remark` | string | 备注 |
| `access_code` | string | 访问码 |
| `unlock_points` | integer | 解锁积分，默认范围 0–10；管理员或拥有 `resource:price_override` 权限的用户编辑精品资源时可设置更高积分 |
| `is_anonymous` | boolean | 是否匿名 |
| `hide_link` | boolean | 通知时是否隐藏链接 |
| `is_completed` | boolean | 是否已完结（仅剧集资源） |
| `notify` | boolean | 是否发送通知，仅管理员或有权限用户有效 |

至少需要提供一个可更新字段。

更新 115 分享时，如果同时提交了带 `password` 参数的 `url` 且未提交非空
`access_code`，服务端会从 URL 自动回填访问码；显式 `access_code` 始终优先。

## DELETE /api/open/shares/:slug

删除分享。只能删除当前用户有权限操作的分享。

### 成功响应

```json
{
  "success": true,
  "code": "200",
  "message": "删除成功"
}
```

## GET /api/open/subscriptions

获取当前授权用户的订阅列表。需要 `subscription` scope。

### 认证与权限

| 项 | 要求 |
|---|---|
| Header | `X-API-Key`、`Authorization: Bearer <user-access-token>` |
| 用户身份 | 必须 |
| scope | `subscription` |

### Query 参数

| 参数 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `target_type` | string | 否 | `publisher`、`media_resource`、`playlist` 或 `tv_follow` |
| `status` | string | 否 | `active`、`canceled` 或 `all`，默认 `active` |
| `q` | string | 否 | 按 `target_key` 模糊搜索 |
| `page` | integer | 否 | 页码，默认 1 |
| `page_size` | integer | 否 | 每页数量，默认 20，最大 100 |

### 响应字段

| 字段 | 类型 | 说明 |
|---|---|---|
| `data[].id` | integer | 订阅 ID |
| `data[].target_type` | string | `publisher`、`media_resource`、`playlist` 或 `tv_follow` |
| `data[].target_id` | integer | 目标内部 ID |
| `data[].target_key` | string | 订阅目标 key |
| `data[].status` | string | `active` 或 `canceled` |
| `data[].title` | string | 订阅对象显示名称，如作者昵称、电影标题、剧集名称、合集名称、片单或追更包标题 |
| `data[].subtitle` | string | 订阅对象辅助信息，如 `@username`、`电影`、`剧集`、`合集`、`片单` 或追更进度 |
| `data[].poster_url` | string | 订阅对象头像或海报地址，可能为空 |
| `data[].href` | string | 站内详情页路径，如 `/user/1`、`/movie/{slug}`、`/tv/{slug}`、`/collection/{tmdb_id}` |
| `data[].canceled_at` | string / null | 取消时间 |
| `data[].created_at` | string | 创建时间 |
| `data[].updated_at` | string | 更新时间 |
| `meta.total` | integer | 总数 |
| `meta.page` | integer | 当前页 |
| `meta.page_size` | integer | 每页数量 |

## POST /api/open/subscriptions

代表当前授权用户订阅作者、媒体资源、片单或已解锁追更包的更新。需要 `subscription` scope。

订阅成功后，平台在匹配目标更新时创建站内信；若用户已绑定 Telegram，则直接推送到该用户绑定的 Telegram 私聊账号。接口不支持指定频道、群组或任意 chat id。追更包在新增/修改条目或标记完结时发送订阅更新。

### 认证与权限

| 项 | 要求 |
|---|---|
| Header | `X-API-Key`、`Authorization: Bearer <user-access-token>` |
| 用户身份 | 必须 |
| scope | `subscription` |
| 用户要求 | 由平台 `subscription_required_level` 设置决定，默认长期 Premium |

### Body 参数

| 参数 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `target_type` | string | 是 | `publisher`、`media_resource`、`playlist` 或 `tv_follow` |
| `target_id` | integer | 是 | 目标内部 ID |
| `target_key` | string | 是 | `publisher:{user_id}`、`movie:{id}`、`tv:{id}`、`collection:{id}`、`playlist:{id}` 或 `tv_follow:{pack_id}`，其中 ID 必须与 `target_id` 一致 |

`tv_follow` 目标要求当前授权用户已经解锁对应追更包。解锁请求仅在显式传入 `subscribe_updates: true` 时创建 active 订阅；用户取消后仍保留解锁访问权，也可以通过本接口重新订阅。不允许当前授权用户订阅自己的 `publisher:{user_id}` 作者目标。

### 请求示例

```bash
curl -X POST https://re0.me/api/open/subscriptions \
  -H "X-API-Key: app-secret" \
  -H "Authorization: Bearer user-access-token" \
  -H "Content-Type: application/json" \
  -d '{
    "target_type": "publisher",
    "target_id": 42,
    "target_key": "publisher:42"
  }'
```

### 成功响应字段

返回字段与 `GET /api/open/subscriptions` 的单个 `data[]` 项一致。重复订阅同一目标会返回已有 active 订阅。

### 常见错误

| 错误码 | HTTP 状态码 | 说明 |
|---|---|---|
| `level_denied` | 403 | 当前用户等级不满足订阅功能门槛 |
| `400` | 400 | 参数缺失、目标类型无效、`target_key` 与 `target_type` / `target_id` 不匹配、订阅自己的作者目标，或尚未解锁目标追更包 |

## GET /api/open/subscriptions/check

检查当前授权用户是否已订阅某个目标。需要 `subscription` scope。

### Query 参数

| 参数 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `target_type` | string | 是 | `publisher`、`media_resource`、`playlist` 或 `tv_follow` |
| `target_key` | string | 是 | `publisher:{user_id}`、`movie:{id}`、`tv:{id}`、`collection:{id}`、`playlist:{id}` 或 `tv_follow:{pack_id}` |

### 成功响应

```json
{
  "success": true,
  "code": "200",
  "message": "success",
  "data": {
    "subscribed": true
  }
}
```

## DELETE /api/open/subscriptions/:id

取消当前授权用户的一条 active 订阅。需要 `subscription` scope。

### Path 参数

| 参数 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `id` | integer | 是 | 订阅 ID |

### 成功响应

```json
{
  "success": true,
  "code": "200",
  "message": "已取消订阅"
}
```

取消订阅只停止后续通知；历史站内信、已产生的 Telegram 消息和历史订阅记录不会被删除。取消 `tv_follow` 订阅不会撤销追更包解锁权限。

## GET /api/open/messages

获取当前授权用户的站内信列表。需要 `messages` scope。

### 认证与权限

| 项 | 要求 |
|---|---|
| Header | `X-API-Key`、`Authorization: Bearer <user-access-token>` |
| 用户身份 | 必须 |
| scope | `messages` |

### Query 参数

| 参数 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `status` | string | 否 | `all`、`unread` 或 `read`，默认 `all` |
| `category` | string | 否 | 站内信分类，例如 `subscription` 或 `system` |
| `subscription_only` | boolean | 否 | 为 `true` 时等价于 `category=subscription` |
| `last_id` | integer | 否 | 游标分页上一页最后一条站内信 ID，默认 `0` |
| `page_size` | integer | 否 | 每页数量，默认 20，最大 100 |

### 响应字段

| 字段 | 类型 | 说明 |
|---|---|---|
| `data[].id` | integer | 站内信 ID |
| `data[].category` | string | 分类，例如 `subscription`、`system` |
| `data[].event_type` | string | 事件类型 |
| `data[].title` | string | 标题 |
| `data[].body` | string | 内容 |
| `data[].link_url` | string / null | 关联跳转 URL |
| `data[].detail_url` | string / null | 详情页 URL |
| `data[].poster_url` | string / null | 海报或头像 URL |
| `data[].source_type` | string / null | 来源对象类型 |
| `data[].source_id` | integer / null | 来源对象 ID |
| `data[].is_read` | boolean | 是否已读 |
| `data[].read_at` | string / null | 已读时间 |
| `data[].created_at` | string | 创建时间 |
| `meta.next_last_id` | integer | 下一页 `last_id`；本页为空时为 `0` |
| `meta.has_more` | boolean | 是否还有下一页 |
| `meta.page_size` | integer | 本次分页大小 |

### 请求示例

```bash
curl -H "X-API-Key: app-secret" \
  -H "Authorization: Bearer user-access-token" \
  "https://re0.me/api/open/messages?subscription_only=true&page_size=20"
```

## GET /api/open/messages/unread-count

获取当前授权用户的站内信未读数。需要 `messages` scope。

### Query 参数

| 参数 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `category` | string | 否 | 站内信分类 |
| `subscription_only` | boolean | 否 | 为 `true` 时只统计订阅类站内信 |

### 成功响应

```json
{
  "success": true,
  "code": "200",
  "message": "success",
  "data": {
    "unread_count": 3
  }
}
```

## POST /api/open/messages/:id/read

标记当前授权用户的一条站内信为已读。需要 `messages` scope。

### Path 参数

| 参数 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `id` | integer | 是 | 站内信 ID |

### 成功响应

```json
{
  "success": true,
  "code": "200",
  "message": "已读",
  "data": {
    "updated_count": 1
  }
}
```

## POST /api/open/messages/read

批量标记当前授权用户的站内信为已读。需要 `messages` scope。

### Body 参数

| 参数 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `ids` | integer[] | 是 | 站内信 ID 列表，最多 100 个；重复和 `0` 会被忽略 |

### 请求示例

```bash
curl -X POST https://re0.me/api/open/messages/read \
  -H "X-API-Key: app-secret" \
  -H "Authorization: Bearer user-access-token" \
  -H "Content-Type: application/json" \
  -d '{"ids":[101,102,103]}'
```

### 成功响应

```json
{
  "success": true,
  "code": "200",
  "message": "已读",
  "data": {
    "updated_count": 3
  }
}
```

`updated_count` 只统计当前用户名下仍处于未读状态并被本次更新的站内信。

## POST /api/open/messages/read-all

标记当前授权用户全部或指定分类站内信为已读。需要 `messages` scope。

### Query 参数

| 参数 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `category` | string | 否 | 站内信分类 |
| `subscription_only` | boolean | 否 | 为 `true` 时只标记订阅类站内信 |

### 成功响应

```json
{
  "success": true,
  "code": "200",
  "message": "已全部标记为已读",
  "data": {
    "updated_count": 5
  }
}
```

## DELETE /api/open/messages/read

删除当前授权用户所有已读站内信。需要 `messages` scope。

该接口不会删除未读站内信，也不会删除其他用户的站内信。

### 成功响应

```json
{
  "success": true,
  "code": "200",
  "message": "已删除已读站内信",
  "data": {
    "deleted_count": 2
  }
}
```


---

## 流媒体榜单与追剧日历

两个接口都需要 `X-API-Key`、代表当前用户的 Bearer Token、`query` scope 和有效 Premium 身份。成功响应使用统一 OpenAPI 外层结构；内部实现、服务配置和缓存细节不属于公开契约。

### GET /api/open/streaming-top

获取指定流媒体平台、地区和媒体类型的当前榜单。榜单条目统一映射为 TMDB 标准数据；未匹配到 TMDB 的条目仍返回榜单名次和源标题，但 TMDB 相关字段为 `null` 或空值。

| 参数 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `provider` | string | 是 | `netflix`、`hbo`、`apple`、`disney`、`crunchyroll`、`prime`、`amazon` 或 `hulu` |
| `region` | string | 否 | `US`、`KR`、`GB` 或 `DE`，默认 `US`；服务端统一转成大写 |
| `media_type` | string | 是 | `movie` 或 `tv` |

兼容旧调用：`service`、`country`、`show_type` 分别作为 `provider`、`region`、`media_type` 的别名；旧值 `series` 会转换为 `tv`。同时提供新旧参数时优先使用新参数。旧 `locale` 参数仍可发送，但不再影响结果。

示例：

```http
GET /api/open/streaming-top?provider=netflix&region=US&media_type=tv
X-API-Key: app-secret
Authorization: Bearer user-access-token
```

成功响应的 `data` 包含以下字段，`meta.count` 为返回条目数：

| `data` 字段 | 类型 | 说明 |
|---|---|---|
| `site` | string | 当前为 `flixpatrol` |
| `date` | string / omitted | 榜单展示日期 |
| `scrape_date` | string | 抓取日期，格式 `YYYY-MM-DD` |
| `scraped_at` | string | 抓取完成时间，RFC 3339 |
| `crawler_cached` | boolean | 是否直接使用抓取服务缓存快照 |
| `provider` | string | 规范化后的平台 |
| `region` | string | 规范化后的地区 |
| `media_type` | string | `movie` 或 `tv` |
| `items` | array | 榜单条目，最多 10 条 |

| `items[]` 字段 | 类型 | 说明 |
|---|---|---|
| `rank` | integer | 榜单名次 |
| `change` | string / omitted | 名次变化原始标记 |
| `days_on_chart` | integer / omitted | 连续在榜天数 |
| `source_title` | string | 榜单中的原始标题 |
| `tmdb_id` | integer / null | TMDB ID |
| `media_type` | string | `movie` 或 `tv` |
| `match_confidence` | number | TMDB 映射置信度，未匹配时通常为 `0` |
| `title` | string | TMDB 本地化标题；未匹配时回退到 `source_title` |
| `original_title` | string / omitted | TMDB 原始标题 |
| `year` | integer / null | 年份 |
| `overview` | string / omitted | TMDB 简介 |
| `rating` | number / null | TMDB 评分 |
| `poster_url` | string / omitted | TMDB 海报地址 |
| `backdrop_url` | string / omitted | TMDB 背景图地址 |
| `release_date` | string / omitted | 电影上映日期或剧集首播日期 |
| `genres` | string[] | 类型名称 |
| `local_media` | object / null | 匹配到 HDHive 站内条目时包含 `id`、`slug`、`href` |
| `subscription` | object | 当前授权用户的订阅状态，包含 `subscribed` 和可选 `subscription_id` |

响应不会返回 FlixPatrol 详情页或其他外部来源链接。`local_media=null` 时，客户端不得根据源标题拼接外部跳转地址。

成功响应示例：

```json
{
  "success": true,
  "code": "200",
  "message": "success",
  "data": {
    "site": "flixpatrol",
    "date": "August 15, 2026",
    "scrape_date": "2026-08-15",
    "scraped_at": "2026-08-16T00:00:00Z",
    "crawler_cached": true,
    "provider": "netflix",
    "region": "US",
    "media_type": "tv",
    "items": [
      {
        "rank": 1,
        "change": "+1",
        "days_on_chart": 8,
        "source_title": "Example Show",
        "tmdb_id": 123,
        "media_type": "tv",
        "match_confidence": 0.98,
        "title": "示例剧集",
        "original_title": "Example Show",
        "year": 2026,
        "overview": "简介",
        "rating": 8.1,
        "poster_url": "https://image.tmdb.org/t/p/w500/poster.jpg",
        "backdrop_url": "https://image.tmdb.org/t/p/w1280/backdrop.jpg",
        "release_date": "2026-08-01",
        "genres": ["剧情"],
        "local_media": {"id": 7, "slug": "example", "href": "/tv/example"},
        "subscription": {"subscribed": true, "subscription_id": 19}
      }
    ]
  },
  "meta": {"count": 1}
}
```

该接口返回固定榜单结果，不提供 `page` 或 `limit` 参数。客户端不应假设能够请求榜单 Top 10 以外的数据。

### GET /api/open/calendar

获取从中国标准时间当天开始的未来播出和上映日历。

| 参数 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `days` | integer | 否 | 默认 `30`，范围 `1-31` |

示例：

```http
GET /api/open/calendar?days=30
X-API-Key: app-secret
Authorization: Bearer user-access-token
```

成功响应的 `data` 字段：

| 字段 | 类型 | 说明 |
|---|---|---|
| `items` | array | 按 `first_aired` 升序排列的电影上映和剧集播出条目 |
| `start_date` | string | 查询窗口在 `Asia/Shanghai` 下的起始日期，格式 `YYYY-MM-DD` |
| `days` | integer | 实际查询天数 |
| `timezone` | string | 固定为 `Asia/Shanghai` |
| `synced_at` | string | 数据同步时间，RFC 3339 |

每个 `items[]` 条目包含以下字段：

| 字段 | 类型 | 说明 |
|---|---|---|
| `first_aired` | string | UTC RFC 3339 时间；电影上映日会规范化为该日期的 UTC 零点 |
| `released` | string / omitted | 电影的 `YYYY-MM-DD` 上映日期；剧集通常省略 |
| `movie` | object / omitted | 电影条目；与 `show` 二选一 |
| `show` | object / omitted | 剧集条目；与 `movie` 二选一 |
| `episode` | object / omitted | 剧集集数信息；电影条目省略 |

`show` 和 `movie` 均包含 `title`、`year`、`ids`，并可能包含 `country`、`status` 和 `metadata`。公开的 `ids` 只包含可用的 `imdb`、`tmdb`、`tvdb`；内部标识不属于公开契约。`show`/`movie` 的 `metadata` 在本地化信息可用时返回，字段为 `name`、`original_name`、`overview`、`poster_path`、`backdrop_path`、`vote_average`、`genre_names` 和可选的 `origin_country`；本地化信息不可用时该字段会省略。`episode` 包含 `season`、`number`、`title`、`first_aired`（可能为 `null`）、可选的 `episode_type` 和 `ids`。

示例响应：

```json
{
  "success": true,
  "code": "200",
  "message": "success",
  "data": {
    "start_date": "2026-08-16",
    "days": 7,
    "timezone": "Asia/Shanghai",
    "synced_at": "2026-08-16T02:00:00Z",
    "items": [
      {
        "first_aired": "2026-08-17T10:00:00Z",
        "show": {
          "title": "Example Show",
          "year": 2026,
          "country": "US",
          "status": "returning series",
          "ids": {"imdb": "tt1234567", "tmdb": 123, "tvdb": 456},
          "metadata": {
            "name": "示例剧集",
            "original_name": "Example Show",
            "overview": "简介",
            "poster_path": "/poster.jpg",
            "backdrop_path": "/backdrop.jpg",
            "vote_average": 8.2,
            "genre_names": ["剧情"],
            "origin_country": "US"
          }
        },
        "episode": {
          "season": 1,
          "number": 2,
          "title": "第二集",
          "first_aired": "2026-08-17T10:00:00Z",
          "episode_type": "standard",
          "ids": {"tmdb": 789, "tvdb": 987}
        }
      }
    ]
  }
}
```

日历窗口按 `Asia/Shanghai` 的当天 00:00 起算，返回条目按 `first_aired` 升序排列。当前只接受 `days` 查询参数；调用方可基于返回的电影、剧集和时间字段自行筛选。

### 常见错误

| HTTP | code | 说明 |
|---|---|---|
| 400 | `invalid_params` | 榜单的 `provider`、`region`、`media_type`，或日历的 `days` 无效 |
| 403 | `VIP_REQUIRED` | 当前授权用户不是有效 Premium 用户 |
| 502 | `502` | 依赖服务暂时不可用或返回格式无效 |
| 503 | `503` | 榜单或日历服务尚未配置 |

---

## 追更包接口

追更接口已经启用。所有接口都需要 `X-API-Key` 和代表当前用户的 Bearer Token；个人 API Key 仍按其绑定用户执行。读取接口使用 `query` scope，发布和维护接口使用 `write` scope，解锁接口使用 `unlock` scope。

解锁和追更通知相互独立。解锁时仅在请求显式传入 `subscribe_updates: true` 后创建 `tv_follow` active 订阅；发布者通过网页或 OpenAPI 新增、修改资源、标记完结时，active 订阅者会进入同一站内信和 Telegram 私聊通知链。用户取消订阅后仍保留已解锁资源访问权。

### GET /api/open/tv-follow/packs

按 TMDB 剧集记录查询追更包。

| 参数 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `tv_id` | integer | 是 | HDHive 剧集 ID |
| `page` | integer | 否 | 默认 1 |
| `page_size` | integer | 否 | 默认 20，最大 50 |

### POST /api/open/tv-follow/packs

创建当前用户的追更包。需要 `write` scope，且当前用户需要角色权限 `tv_follow:create`（管理员直接放行）。

```json
{
  "tv_id": 123,
  "title": "仙逆 4K 持续更新",
  "remark": "每周更新",
  "unlock_points": 10,
  "video_resolution": "4K",
  "source": "WEB-DL",
  "subtitle_language": "简中",
  "subtitle_type": "内封",
  "updated_to_label": "S01E100",
  "is_completed": false
}
```

`tv_id` 和 `title` 必填；`unlock_points` 发布范围为 0–10。成功后返回追更包 `id`、`slug`、规格、进度和统计字段。

### GET /api/open/tv-follow/packs/:slug

获取追更包详情。返回 `is_owner` 和 `is_unlocked`。尚未解锁且不是发布者时，仅在 `preview_items` 返回季、集数、类型和标签，不返回链接。`preview_items` 与完整资源列表使用相同的最新优先顺序。

### PATCH /api/open/tv-follow/packs/:slug

部分更新自己发布的追更包。需要 `write` scope。支持：

- `title`、`remark`、`unlock_points`
- `video_resolution`、`source`、`subtitle_language`、`subtitle_type`
- `default_remark`、`default_quality`、`updated_to_label`、`is_completed`

更新 `unlock_points` 时同样必须保持在 0–10 范围内。

`is_completed` 首次改为 `true` 时会向 active 追更订阅者发送完结更新。

### DELETE /api/open/tv-follow/packs/:slug

删除自己发布的追更包。需要 `write` scope。该操作使用软删除且不可从 OpenAPI 恢复。

### POST /api/open/tv-follow/packs/:slug/unlock

代表当前用户解锁追更资源。需要 `unlock` scope，并受 OpenAPI 用户动作限速保护。请求体可为空；`subscribe_updates` 默认为 `false`，仅设为 `true` 时开启追更信息通知。

```json
{
  "subscribe_updates": true
}
```

响应示例：

```json
{
  "success": true,
  "code": "200",
  "message": "解锁成功",
  "data": {
    "pack_id": 88,
    "already_owned": false,
    "points_spent": 20
  }
}
```

重复解锁不会重复扣费。不传请求体或传入 `subscribe_updates: false` 时只解锁资源，不创建订阅；传入 `true` 会创建或恢复 active `tv_follow` 订阅。

### GET /api/open/tv-follow/packs/:slug/items

获取完整资源列表。发布者和已解锁用户可访问；否则返回 `403 not_unlocked`。成功响应的每条资源包含标签、链接类型、完整链接、访问码、规格、备注和时间字段。

其中 ED2K 条目在 SIZE 水印开关开启时同样按当前用户改写数字 `SIZE`，不附加自定义扩展字段；MD4 哈希保持不变。该 `SIZE` 仅承载 115 离线场景的用户水印，不代表真实字节数；重命名文件名或删除尾部可选字段后仍可由管理员反查。开关关闭时，新返回的条目保留原始真实 `SIZE`。

列表默认按 `season DESC, episode_end DESC, episode_start DESC, id DESC` 返回，第一条就是当前最新季集；客户端无需再反转数组。

### POST /api/open/tv-follow/packs/:slug/items

批量新增资源。需要 `write` scope，只允许追更包发布者调用。单次最多 500 条；`entries` 为推荐字段，兼容 `items`。

```json
{
  "entries": [
    {
      "episode_label": "S01E101",
      "url": "ed2k://|file|Example.S01E101.mkv|123|HASH|/",
      "video_resolution": "4K",
      "source": "WEB-DL",
      "subtitle_language": "简中"
    },
    {
      "episode_label": "S01E102",
      "url": "magnet:?xt=urn:btih:example"
    }
  ]
}
```

单条字段支持 `episode_label`（兼容 `label`）、`url`（兼容 `link`）、`access_code`、`remark`、`video_resolution`、`source`、`subtitle_language`、`subtitle_type`。支持 115、ED2K 和磁力链接。

服务端独立校验每一条，有效条目在一个事务内写入；重复或格式错误不会阻塞其他有效条目。响应返回：

| 字段 | 说明 |
|---|---|
| `total_count` | 本次输入条目数 |
| `created_count` | 新增成功数 |
| `skipped_count` | 重复标签或重复链接数 |
| `failed_count` | 格式或链接校验失败数 |
| `rows[]` | 每条的 `index`、`label`、`url`、`status`、`code`、`message` 和可选 `item` |

超过 500 条返回 HTTP `400`、code=`too_many`。新增成功后会合并生成一次追更订阅更新，不会按 500 条逐条轰炸订阅者。

### PATCH /api/open/tv-follow/items/:id

部分更新自己发布的资源。需要 `write` scope。支持 `url`（兼容 `link`）、`access_code`、`remark`、`video_resolution`、`source`、`subtitle_language`、`subtitle_type`。至少提供一个字段；修改成功会进入同一追更订阅更新链。

### DELETE /api/open/tv-follow/items/:id

删除自己发布的资源。需要 `write` scope。

### GET /api/open/tv-follow/my

获取当前用户已经解锁的追更包。

| 参数 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `page` | integer | 否 | 默认 1 |
| `page_size` | integer | 否 | 默认 20 |

返回解锁信息、追更包摘要和 `unread_count`。

### 常见错误

| HTTP | code | 说明 |
|---|---|---|
| 400 | `invalid_params` | 参数或资源格式错误 |
| 400 | `too_many` | 单次新增超过 500 条 |
| 400 | `insufficient_points` | 当前用户积分不足 |
| 403 | `permission_denied` | 不是追更包发布者 |
| 403 | `not_unlocked` | 尚未解锁追更包 |
| 404 | `404` | 追更包或资源不存在 |
