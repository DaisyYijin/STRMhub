package hdhiveopenapi

import (
	"context"
	"crypto/hmac"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

func TestOAuthClientBuildAuthorizeURL(t *testing.T) {
	client := NewOAuthClient("https://hdhive.com", "app_client", "app_secret")
	url, err := client.BuildAuthorizeURL("https://client.example.com/callback", "state-123", "postmessage", "meta query")
	if err != nil {
		t.Fatalf("BuildAuthorizeURL returned error: %v", err)
	}
	if !strings.Contains(url, "client_id=app_client") || !strings.Contains(url, "response_mode=postmessage") {
		t.Fatalf("unexpected authorize url: %s", url)
	}
}

func TestClientParsesStructuredOpenAPIErrors(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusUnauthorized)
		_ = json.NewEncoder(w).Encode(APIResponse[map[string]any]{
			Success:     false,
			Code:        "OPENAPI_REFRESH_REQUIRED",
			Message:     "token expired",
			Description: "refresh the token",
		})
	}))
	defer server.Close()

	client := NewClient(server.URL, "app_secret")
	_, err := client.GetQuota(context.Background())
	var openAPIErr *OpenAPIError
	if !errors.As(err, &openAPIErr) {
		t.Fatalf("expected OpenAPIError, got %v", err)
	}
	if openAPIErr.Code != "OPENAPI_REFRESH_REQUIRED" || openAPIErr.Status != http.StatusUnauthorized {
		t.Fatalf("unexpected error: %#v", openAPIErr)
	}
}

func TestRequestWithRefreshRetryRefreshesOnce(t *testing.T) {
	requestCalls := 0
	refreshCalls := 0
	tokens := &TokenSet{AccessToken: "expired", RefreshToken: "refresh-1"}

	resp, updatedTokens, err := RequestWithRefreshRetry(context.Background(), tokens,
		func(ctx context.Context, accessToken string) (*APIResponse[map[string]any], error) {
			requestCalls++
			if requestCalls == 1 {
				return nil, &OpenAPIError{Status: 401, Code: "OPENAPI_REFRESH_REQUIRED", Message: "expired"}
			}
			return &APIResponse[map[string]any]{Success: true, Data: map[string]any{"pong": "ok"}}, nil
		},
		func(ctx context.Context, refreshToken string) (*TokenSet, error) {
			refreshCalls++
			return &TokenSet{AccessToken: "fresh", RefreshToken: "refresh-2", TokenType: "Bearer"}, nil
		},
	)
	if err != nil {
		t.Fatalf("RequestWithRefreshRetry returned error: %v", err)
	}
	if requestCalls != 2 || refreshCalls != 1 {
		t.Fatalf("unexpected retry counts: request=%d refresh=%d", requestCalls, refreshCalls)
	}
	if updatedTokens.AccessToken != "fresh" || resp.Data["pong"] != "ok" {
		t.Fatalf("unexpected retry result: tokens=%#v resp=%#v", updatedTokens, resp)
	}
}

func TestRequestWithRefreshRetryPropagatesReauthRequiredFromRefresh(t *testing.T) {
	tokens := &TokenSet{AccessToken: "expired", RefreshToken: "refresh-1"}

	_, _, err := RequestWithRefreshRetry(context.Background(), tokens,
		func(ctx context.Context, accessToken string) (*APIResponse[map[string]any], error) {
			return nil, &OpenAPIError{Status: 401, Code: "OPENAPI_REFRESH_REQUIRED", Message: "expired"}
		},
		func(ctx context.Context, refreshToken string) (*TokenSet, error) {
			return nil, &OpenAPIError{Status: 401, Code: "OPENAPI_REAUTH_REQUIRED", Message: "reauthorize"}
		},
	)

	var openAPIErr *OpenAPIError
	if !errors.As(err, &openAPIErr) {
		t.Fatalf("expected OpenAPIError, got %v", err)
	}
	if openAPIErr.Code != "OPENAPI_REAUTH_REQUIRED" {
		t.Fatalf("unexpected error: %#v", openAPIErr)
	}
}

func TestVerifyWebhookSignatureAcceptsValidSignature(t *testing.T) {
	signatureHeader := "t=1716055200,v1=" + signedWebhookHex(hashOpenAPISecretForTest("webhook-secret"), "1716055200.oauth-code.demo-state.app_client")
	result, err := VerifyWebhookSignature("webhook-secret", signatureHeader, "oauth-code", "demo-state", "app_client")
	if err != nil {
		t.Fatalf("VerifyWebhookSignature returned error: %v", err)
	}
	if !result.Valid {
		t.Fatalf("expected valid signature result, got %#v", result)
	}
}

func hashOpenAPISecretForTest(raw string) string {
	sum := sha256.Sum256([]byte(raw))
	return hex.EncodeToString(sum[:])
}

func signedWebhookHex(secret, payload string) string {
	mac := hmac.New(sha256.New, []byte(secret))
	mac.Write([]byte(payload))
	return hex.EncodeToString(mac.Sum(nil))
}
