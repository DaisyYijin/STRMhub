module hdhive-openapi-sdk

go 1.21
