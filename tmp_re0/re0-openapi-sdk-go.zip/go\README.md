# RE0 OpenAPI Go SDK

## Installation

Copy the `go/` directory into your project or import it as a local module during evaluation.

## OAuth Helpers

```go
oauth := hdhiveopenapi.NewOAuthClient("https://re0.me", "app_client", "app_secret")
authorizeURL, _ := oauth.BuildAuthorizeURL(
  "https://client.example.com/callback",
  "state-123",
  "postmessage",
  "meta query",
)
```

## Business Client

```go
client := hdhiveopenapi.NewClient("https://re0.me", "app_secret").WithAccessToken("user-access-token")
quota, err := client.GetQuota(context.Background())
```

## Unlock Resource

```go
result, err := client.UnlockResource(context.Background(), "a1b2c3d4e5f647898765432112345678")
_ = result
_ = err
```

`UnlockResource(...)` 当前封装的是单资源解锁，请求体等价于 `{"slug":"..."}`。

如果你要调用批量解锁接口，HTTP API 本身已经支持：

```json
{"slugs":["slug-a","slug-b"]}
```

当前这个 Go SDK README 只提供单资源 helper。批量解锁建议直接调用 `POST /api/open/resources/unlock`，或在复制到本地项目后的 SDK 上补一个 batch helper。

## Refresh Retry Helper

```go
resp, updatedTokens, err := hdhiveopenapi.RequestWithRefreshRetry(
  context.Background(),
  tokens,
  func(ctx context.Context, accessToken string) (*hdhiveopenapi.APIResponse[map[string]any], error) {
    return client.WithAccessToken(accessToken).GetQuota(ctx)
  },
  func(ctx context.Context, refreshToken string) (*hdhiveopenapi.TokenSet, error) {
    return oauth.RefreshToken(ctx, refreshToken)
  },
)
_ = resp
_ = updatedTokens
_ = err
```

`RequestWithRefreshRetry` 只会在业务请求返回 `OPENAPI_REFRESH_REQUIRED` 时 refresh 一次；如果 refresh 本身返回 `OPENAPI_REAUTH_REQUIRED`，应重新拉起 OAuth 授权流程。

## Webhook Signature Verification

```go
result, err := hdhiveopenapi.VerifyWebhookSignature(
  "raw-webhook-secret",
  "t=1716055200,v1=<hex>",
  "authorization-code",
  "oauth-state",
  "app_client",
)
```
