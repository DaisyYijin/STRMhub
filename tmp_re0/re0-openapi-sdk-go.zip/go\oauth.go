package hdhiveopenapi

import (
	"context"
	"crypto/hmac"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"net/http"
	"net/url"
	"strconv"
	"strings"
	"time"
)

type OAuthClient struct {
	BaseURL    string
	ClientID   string
	AppSecret  string
	HTTPClient *http.Client
}

type TokenSet struct {
	AccessToken      string   `json:"access_token"`
	RefreshToken     string   `json:"refresh_token"`
	TokenType        string   `json:"token_type"`
	ExpiresIn        int64    `json:"expires_in"`
	RefreshExpiresIn int64    `json:"refresh_expires_in"`
	Scope            string   `json:"scope"`
	Scopes           []string `json:"scopes"`
}

type WebhookSignatureResult struct {
	Valid             bool   `json:"valid"`
	Timestamp         int64  `json:"timestamp"`
	ExpectedSignature string `json:"expected_signature"`
	ActualSignature   string `json:"actual_signature"`
}

func NewOAuthClient(baseURL, clientID, appSecret string) *OAuthClient {
	return &OAuthClient{
		BaseURL:   strings.TrimRight(strings.TrimSpace(baseURL), "/"),
		ClientID:  strings.TrimSpace(clientID),
		AppSecret: strings.TrimSpace(appSecret),
		HTTPClient: &http.Client{
			Timeout: 30 * time.Second,
		},
	}
}

func (c *OAuthClient) BuildAuthorizeURL(redirectURI, state, responseMode, scope string) (string, error) {
	if c == nil {
		return "", fmt.Errorf("oauth client is required")
	}
	if c.BaseURL == "" || c.ClientID == "" {
		return "", fmt.Errorf("base URL and client ID are required")
	}
	parsed, err := url.Parse(c.BaseURL)
	if err != nil {
		return "", err
	}
	parsed.Path = strings.TrimRight(parsed.Path, "/") + "/openapi/authorize"
	query := parsed.Query()
	query.Set("client_id", c.ClientID)
	query.Set("redirect_uri", strings.TrimSpace(redirectURI))
	if strings.TrimSpace(state) != "" {
		query.Set("state", strings.TrimSpace(state))
	}
	if strings.TrimSpace(responseMode) != "" {
		query.Set("response_mode", strings.TrimSpace(responseMode))
	}
	if strings.TrimSpace(scope) != "" {
		query.Set("scope", strings.TrimSpace(scope))
	}
	parsed.RawQuery = query.Encode()
	return parsed.String(), nil
}

func (c *OAuthClient) ExchangeAuthorizationCode(ctx context.Context, code, redirectURI string) (*TokenSet, error) {
	return c.tokenRequest(ctx, "/api/public/openapi/oauth/token", map[string]any{
		"grant_type":   "authorization_code",
		"code":         strings.TrimSpace(code),
		"redirect_uri": strings.TrimSpace(redirectURI),
	})
}

func (c *OAuthClient) RefreshToken(ctx context.Context, refreshToken string) (*TokenSet, error) {
	return c.tokenRequest(ctx, "/api/public/openapi/oauth/refresh", map[string]any{
		"refresh_token": strings.TrimSpace(refreshToken),
	})
}

func (c *OAuthClient) RevokeRefreshToken(ctx context.Context, refreshToken string) error {
	_, err := c.request(ctx, http.MethodPost, "/api/public/openapi/oauth/revoke", map[string]any{
		"refresh_token": strings.TrimSpace(refreshToken),
	})
	return err
}

func (c *OAuthClient) tokenRequest(ctx context.Context, path string, body map[string]any) (*TokenSet, error) {
	resp, err := c.request(ctx, http.MethodPost, path, body)
	if err != nil {
		return nil, err
	}

	token := &TokenSet{}
	if value, ok := resp.Data["access_token"].(string); ok {
		token.AccessToken = value
	}
	if value, ok := resp.Data["refresh_token"].(string); ok {
		token.RefreshToken = value
	}
	if value, ok := resp.Data["token_type"].(string); ok {
		token.TokenType = value
	}
	if value, ok := resp.Data["expires_in"].(float64); ok {
		token.ExpiresIn = int64(value)
	}
	if value, ok := resp.Data["refresh_expires_in"].(float64); ok {
		token.RefreshExpiresIn = int64(value)
	}
	if value, ok := resp.Data["scope"].(string); ok {
		token.Scope = value
	}
	if scopes, ok := resp.Data["scopes"].([]any); ok {
		token.Scopes = make([]string, 0, len(scopes))
		for _, scope := range scopes {
			if text, ok := scope.(string); ok {
				token.Scopes = append(token.Scopes, text)
			}
		}
	}
	return token, nil
}

func (c *OAuthClient) request(ctx context.Context, method, path string, body map[string]any) (*APIResponse[map[string]any], error) {
	client := &Client{
		BaseURL:     c.BaseURL,
		APIKey:      c.AppSecret,
		HTTPClient:  c.HTTPClient,
		AccessToken: "",
	}
	return doJSON[map[string]any](client, ctx, method, path, nil, body)
}

func RequestWithRefreshRetry[T any](
	ctx context.Context,
	tokens *TokenSet,
	request func(context.Context, string) (*APIResponse[T], error),
	refresh func(context.Context, string) (*TokenSet, error),
) (*APIResponse[T], *TokenSet, error) {
	if tokens == nil {
		return nil, nil, fmt.Errorf("tokens are required")
	}
	resp, err := request(ctx, strings.TrimSpace(tokens.AccessToken))
	if err == nil {
		return resp, tokens, nil
	}

	var openAPIErr *OpenAPIError
	if !errorsAsOpenAPI(err, &openAPIErr) || openAPIErr.Code != "OPENAPI_REFRESH_REQUIRED" {
		return nil, tokens, err
	}
	if strings.TrimSpace(tokens.RefreshToken) == "" {
		return nil, tokens, err
	}

	updatedTokens, refreshErr := refresh(ctx, strings.TrimSpace(tokens.RefreshToken))
	if refreshErr != nil {
		return nil, tokens, refreshErr
	}
	resp, err = request(ctx, strings.TrimSpace(updatedTokens.AccessToken))
	if err != nil {
		return nil, updatedTokens, err
	}
	return resp, updatedTokens, nil
}

func VerifyWebhookSignature(rawSecret, signatureHeader, code, state, clientID string) (*WebhookSignatureResult, error) {
	timestamp, actualSignature, err := parseWebhookSignatureHeader(signatureHeader)
	if err != nil {
		return nil, err
	}
	secretHash := sha256Hex(strings.TrimSpace(rawSecret))
	message := fmt.Sprintf("%d.%s.%s.%s", timestamp, strings.TrimSpace(code), strings.TrimSpace(state), strings.TrimSpace(clientID))
	expectedSignature := hmacHex(secretHash, message)
	return &WebhookSignatureResult{
		Valid:             hmac.Equal([]byte(strings.ToLower(expectedSignature)), []byte(strings.ToLower(actualSignature))),
		Timestamp:         timestamp,
		ExpectedSignature: expectedSignature,
		ActualSignature:   actualSignature,
	}, nil
}

func parseWebhookSignatureHeader(header string) (int64, string, error) {
	var timestamp int64
	var signature string
	for _, part := range strings.Split(strings.TrimSpace(header), ",") {
		key, value, ok := strings.Cut(strings.TrimSpace(part), "=")
		if !ok {
			continue
		}
		switch key {
		case "t":
			parsed, err := strconv.ParseInt(strings.TrimSpace(value), 10, 64)
			if err != nil {
				return 0, "", fmt.Errorf("invalid timestamp in signature header: %w", err)
			}
			timestamp = parsed
		case "v1":
			signature = strings.TrimSpace(value)
		}
	}
	if timestamp == 0 || signature == "" {
		return 0, "", fmt.Errorf("signature header must contain t=<unix>,v1=<hex>")
	}
	return timestamp, signature, nil
}

func sha256Hex(raw string) string {
	sum := sha256.Sum256([]byte(raw))
	return hex.EncodeToString(sum[:])
}

func hmacHex(secret, payload string) string {
	mac := hmac.New(sha256.New, []byte(secret))
	mac.Write([]byte(payload))
	return hex.EncodeToString(mac.Sum(nil))
}

func errorsAsOpenAPI(err error, target **OpenAPIError) bool {
	if err == nil {
		return false
	}
	openAPIErr, ok := err.(*OpenAPIError)
	if ok {
		*target = openAPIErr
		return true
	}
	return false
}
