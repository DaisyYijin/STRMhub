package hdhiveopenapi

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strings"
	"time"
)

type Client struct {
	BaseURL     string
	APIKey      string
	AccessToken string
	HTTPClient  *http.Client
}

type APIResponse[T any] struct {
	Success     bool           `json:"success"`
	Code        string         `json:"code"`
	Message     string         `json:"message"`
	Description string         `json:"description,omitempty"`
	Data        T              `json:"data"`
	Meta        map[string]any `json:"meta,omitempty"`
}

type OpenAPIError struct {
	Status      int
	Code        string
	Message     string
	Description string
	Body        []byte
}

func (e *OpenAPIError) Error() string {
	if e == nil {
		return ""
	}
	if strings.TrimSpace(e.Description) != "" {
		return strings.TrimSpace(e.Description)
	}
	if strings.TrimSpace(e.Message) != "" {
		return strings.TrimSpace(e.Message)
	}
	if strings.TrimSpace(e.Code) != "" {
		return strings.TrimSpace(e.Code)
	}
	return fmt.Sprintf("OpenAPI request failed with status %d", e.Status)
}

func NewClient(baseURL, apiKey string) *Client {
	return &Client{
		BaseURL: strings.TrimRight(strings.TrimSpace(baseURL), "/"),
		APIKey:  strings.TrimSpace(apiKey),
		HTTPClient: &http.Client{
			Timeout: 30 * time.Second,
		},
	}
}

func (c *Client) WithAccessToken(token string) *Client {
	c.AccessToken = strings.TrimSpace(token)
	return c
}

func (c *Client) Ping(ctx context.Context) (*APIResponse[map[string]any], error) {
	return doJSON[map[string]any](c, ctx, http.MethodGet, "/api/open/ping", nil, nil)
}

func (c *Client) GetQuota(ctx context.Context) (*APIResponse[map[string]any], error) {
	return doJSON[map[string]any](c, ctx, http.MethodGet, "/api/open/quota", nil, nil)
}

func (c *Client) GetUsage(ctx context.Context) (*APIResponse[map[string]any], error) {
	return doJSON[map[string]any](c, ctx, http.MethodGet, "/api/open/usage", nil, nil)
}

func (c *Client) GetUsageToday(ctx context.Context) (*APIResponse[map[string]any], error) {
	return doJSON[map[string]any](c, ctx, http.MethodGet, "/api/open/usage/today", nil, nil)
}

func (c *Client) QueryResources(ctx context.Context, mediaType, tmdbID string) (*APIResponse[[]map[string]any], error) {
	path := fmt.Sprintf("/api/open/resources/%s/%s", url.PathEscape(mediaType), url.PathEscape(tmdbID))
	return doJSON[[]map[string]any](c, ctx, http.MethodGet, path, nil, nil)
}

func (c *Client) UnlockResource(ctx context.Context, slug string) (*APIResponse[map[string]any], error) {
	return doJSON[map[string]any](c, ctx, http.MethodPost, "/api/open/resources/unlock", nil, map[string]string{"slug": slug})
}

func (c *Client) DebitPoints(ctx context.Context, amount int, idempotencyKey, reason, externalRef string) (*APIResponse[map[string]any], error) {
	payload := map[string]any{
		"amount":          amount,
		"idempotency_key": idempotencyKey,
		"reason":          reason,
	}
	if externalRef != "" {
		payload["external_ref"] = externalRef
	}
	return doJSON[map[string]any](c, ctx, http.MethodPost, "/api/open/points/debit", nil, payload)
}

func (c *Client) RefundPoints(ctx context.Context, transactionID uint, idempotencyKey, reason string, amount *int) (*APIResponse[map[string]any], error) {
	payload := map[string]any{
		"transaction_id":  transactionID,
		"idempotency_key": idempotencyKey,
		"reason":          reason,
	}
	if amount != nil {
		payload["amount"] = *amount
	}
	return doJSON[map[string]any](c, ctx, http.MethodPost, "/api/open/points/refund", nil, payload)
}

func (c *Client) CheckResource(ctx context.Context, resourceURL string) (*APIResponse[map[string]any], error) {
	return doJSON[map[string]any](c, ctx, http.MethodPost, "/api/open/check/resource", nil, map[string]string{"url": resourceURL})
}

func (c *Client) GetMe(ctx context.Context) (*APIResponse[map[string]any], error) {
	return doJSON[map[string]any](c, ctx, http.MethodGet, "/api/open/me", nil, nil)
}

func (c *Client) GetVipEntitlements(ctx context.Context) (*APIResponse[map[string]any], error) {
	return doJSON[map[string]any](c, ctx, http.MethodGet, "/api/open/vip/entitlements", nil, nil)
}

func (c *Client) GetWeeklyFreeQuota(ctx context.Context) (*APIResponse[map[string]any], error) {
	return doJSON[map[string]any](c, ctx, http.MethodGet, "/api/open/vip/weekly-free-quota", nil, nil)
}

func (c *Client) Checkin(ctx context.Context) (*APIResponse[map[string]any], error) {
	return doJSON[map[string]any](c, ctx, http.MethodPost, "/api/open/checkin", nil, nil)
}

func (c *Client) ListShares(ctx context.Context) (*APIResponse[[]map[string]any], error) {
	return doJSON[[]map[string]any](c, ctx, http.MethodGet, "/api/open/shares", nil, nil)
}

func (c *Client) GetShareDetail(ctx context.Context, slug string) (*APIResponse[map[string]any], error) {
	return doJSON[map[string]any](c, ctx, http.MethodGet, "/api/open/shares/"+url.PathEscape(slug), nil, nil)
}

func (c *Client) CreateShare(ctx context.Context, payload map[string]any) (*APIResponse[map[string]any], error) {
	return doJSON[map[string]any](c, ctx, http.MethodPost, "/api/open/shares", nil, payload)
}

func (c *Client) UpdateShare(ctx context.Context, slug string, payload map[string]any) (*APIResponse[map[string]any], error) {
	return doJSON[map[string]any](c, ctx, http.MethodPatch, "/api/open/shares/"+url.PathEscape(slug), nil, payload)
}

func (c *Client) DeleteShare(ctx context.Context, slug string) (*APIResponse[map[string]any], error) {
	return doJSON[map[string]any](c, ctx, http.MethodDelete, "/api/open/shares/"+url.PathEscape(slug), nil, nil)
}

func doJSON[T any](c *Client, ctx context.Context, method, path string, query url.Values, body any) (*APIResponse[T], error) {
	httpClient, req, err := c.newRequest(ctx, method, path, query, body)
	if err != nil {
		return nil, err
	}

	resp, err := httpClient.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	return decodeAPIResponse[T](resp)
}

func (c *Client) newRequest(ctx context.Context, method, path string, query url.Values, body any) (*http.Client, *http.Request, error) {
	if c == nil {
		return nil, nil, fmt.Errorf("client is required")
	}
	if c.BaseURL == "" {
		return nil, nil, fmt.Errorf("base URL is required")
	}
	if c.APIKey == "" {
		return nil, nil, fmt.Errorf("API key is required")
	}

	requestURL := c.BaseURL + path
	if len(query) > 0 {
		requestURL += "?" + query.Encode()
	}

	var reader io.Reader
	if body != nil {
		payload, err := json.Marshal(body)
		if err != nil {
			return nil, nil, err
		}
		reader = bytes.NewReader(payload)
	}

	req, err := http.NewRequestWithContext(ctx, method, requestURL, reader)
	if err != nil {
		return nil, nil, err
	}
	req.Header.Set("X-API-Key", c.APIKey)
	req.Header.Set("Accept", "application/json")
	if body != nil {
		req.Header.Set("Content-Type", "application/json")
	}
	if c.AccessToken != "" {
		req.Header.Set("Authorization", "Bearer "+c.AccessToken)
	}

	httpClient := c.HTTPClient
	if httpClient == nil {
		httpClient = &http.Client{Timeout: 30 * time.Second}
	}
	return httpClient, req, nil
}

func decodeAPIResponse[T any](resp *http.Response) (*APIResponse[T], error) {
	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, err
	}
	if len(bytes.TrimSpace(body)) == 0 {
		return &APIResponse[T]{Success: resp.StatusCode < 400}, nil
	}

	var apiResp APIResponse[T]
	if err := json.Unmarshal(body, &apiResp); err != nil {
		if resp.StatusCode >= 400 {
			return nil, &OpenAPIError{
				Status: resp.StatusCode,
				Code:   strconvStatus(resp.StatusCode),
				Body:   body,
			}
		}
		return nil, err
	}
	if resp.StatusCode >= 400 || (!apiResp.Success && strings.TrimSpace(apiResp.Code) != "") {
		return nil, &OpenAPIError{
			Status:      resp.StatusCode,
			Code:        apiResp.Code,
			Message:     apiResp.Message,
			Description: apiResp.Description,
			Body:        body,
		}
	}
	return &apiResp, nil
}

func strconvStatus(status int) string {
	return fmt.Sprintf("%d", status)
}
